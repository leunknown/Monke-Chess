/*
    Project for EECS22L Spring 2022

    Initial Author: Zachary Nicholson

    Gui.h: header file for Graphical interaction with the chess game
*/

#ifndef _GUI_H
#define _GUI_H

#include <gtk/gtk.h>
#include "Piece.h"
#include "Board.h"
#include "string.h"

#define MAX_MSGLEN  100 
#define SQUARE_SIZE 50  
#define WINDOW_BORDER 10
#define BOARD_BORDER 10
#define BOARD_WIDTH  (8*SQUARE_SIZE)
#define BOARD_HEIGHT (8*SQUARE_SIZE)
#define WINDOW_WIDTH  (BOARD_WIDTH + 2*BOARD_BORDER)
#define WINDOW_HEIGHT (BOARD_HEIGHT + 2*BOARD_BORDER)


typedef struct gameasset{
    char **dark_white  ;  // Holds filepaths to white pieces on dark tiles
    char **dark_black  ;  // Holds filepaths to black pieces on dark tiles
    char **light_white ;  // Holds filepaths to white pieces on light tiles
    char **light_black ;  // Holds filepaths to black pieces on light tiles
    char  *light       ;  // Holds filepaths to light background  
    char  *dark        ;  // Holds filepaths to dark background
    PIECE** board;        // Holds current game board 
    Colors  team;         // holds enum for player color/team
    MOVELIST *pastmoves;  // holds theos movelist for en passant
}GAME_ASSET;

int click1_x;               // persistent variables for click coord saving
int click1_y;
int click2_x;
int click2_y;




void InitBoard(GAME_ASSET *Asset); // Initialize a background reference for the GUI to check 

void DrawBoard( GAME_ASSET *Asset); // Fills a GTK table with the correct image for each space on the board

void CoordToGrid(int c_x, int c_y, int *g_x, int *g_y); // Converts absolute click coordinates to gameboard coordinates

gboolean on_delete_event(GtkWidget *widget, 
         GdkEvent  *event,
         gpointer   data);

gint area_click(GtkWidget *widget,             // GtkCallback function triggered on mouse click
                 GdkEvent  *event,              // gets coords and calls CoordToGrid()
                 gpointer  data);


gboolean make_ai_move(GAME_ASSET* Asset); // calls AI to make a move and display it

#endif