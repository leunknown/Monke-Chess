/*
    Project for EECS22L Spring 2022

    Initial Author: Zachary Nicholson

    Gui.c: header file for Graphical interaction with the chess game
*/

#include "Gui.h"
#include "AI.h"

GtkWidget *window;
GtkWidget *fixed;

GtkWidget *chess_icon;
GtkWidget *chess_icon2;
GtkWidget *table;
GtkWidget *table2;

Colors Board[8][8]; // Stores space color reference



// Initialize a reference checkerboard of 0's and 1's to denote light and dark squares
// Also init click coords to wait for click
void InitBoard(GAME_ASSET *Asset)
{
    click1_x = 8;
    click1_y = 8;
    click2_x = 8;
    click2_y = 8;

    int i, j = 0;
    for (i = 0; i < 8; i++){
        for (j = 0; j < 8; j++){
            if (j % 2){
                if (i % 2){
                    Board[i][j] = white;
                }
                else{
                    Board[i][j] = black;
                }
            }
            else{
                if (i % 2){
                    Board[i][j] = black;
                }
                else{
                    Board[i][j] = white;
                }
            }
        }
    }
}

// Has AI choose a move and checks if it is in check
gboolean make_ai_move(GAME_ASSET *Asset){

    if (RandomMove(Asset->board, !Asset->team, Asset->pastmoves)){
        return TRUE;
    }
    return FALSE;


}

// populate Gtk Table with the current boardstate of all piece images
void DrawBoard(GAME_ASSET *Asset)
{   
    for(int i = 0; i < 8 ; i++){
        for(int j = 0; j<8; j++){
            PIECE *Piece = Asset->board[8*(7-j)+i];
            switch (Board[i][j])
            {

            case black:
                if (Piece == NULL) {
                    chess_icon = gtk_image_new_from_file(Asset->dark);
                }
                else{
                        if (!Piece->Color)
                        {
                            chess_icon = gtk_image_new_from_file(Asset->dark_black[Piece->PieceType]); // load a blank dark space
                        }
                        else if (Piece->Color)
                        {
                            chess_icon = gtk_image_new_from_file(Asset->dark_white[Piece->PieceType]); // load a blank dark space
                        }
                }
                gtk_table_attach(GTK_TABLE(table), chess_icon, i, i + 1, j, j + 1, GTK_FILL, GTK_FILL, 0, 0);
                break;

                    
                    
            case white:
                if (Piece == NULL){
                    chess_icon = gtk_image_new_from_file(Asset->light);
                }
                else {
                
                    if (!Piece->Color){
                        chess_icon = gtk_image_new_from_file(Asset->light_black[Piece->PieceType]); // load a blank dark space
                    }
                    else if (Piece->Color){
                        chess_icon = gtk_image_new_from_file(Asset->light_white[Piece->PieceType]); // load a blank dark space
                    }
                }
                gtk_table_attach(GTK_TABLE(table), chess_icon, i, i + 1, j, j + 1, GTK_FILL, GTK_FILL, 0, 0);
                break;
            }
    }
}
}

// converts graphical coordinates to rank and file
void CoordToGrid(int c_x, int c_y, int *g_x, int *g_y)
{ 
    *g_x = (c_x - BOARD_BORDER) / SQUARE_SIZE;
    *g_y = 7 - (c_y - BOARD_BORDER) / SQUARE_SIZE;
}

// triggers the GTK quit process, frees graphical resources
gboolean on_delete_event(GtkWidget *widget, 
                         GdkEvent *event,
                         gpointer data)
{
    g_print("delete event occurred\n");
    gtk_main_quit();
    return FALSE;
}

// triggered on user mouseclick, proccesses input and calls on game logic
gint area_click(GtkWidget *widget, 
                GdkEvent *event,   // gets coords and calls CoordToGrid()
                gpointer data)
{                                  // then decides if move should be stored and displayed or not
    
    GAME_ASSET* Asset = data; // format the input pointer for the Game assets
    PIECE* Piece;             
    int coord_x, coord_y, grid_x, grid_y;
    int color;

    

    GdkModifierType state;

    gdk_window_get_pointer(widget->window, &coord_x, &coord_y, &state);

    CoordToGrid(coord_x, coord_y, &grid_x, &grid_y);

    //printf("coord_x = %d, coord_y = %d, grid_x = %d, grid_y = %d \n", coord_x, coord_y, grid_x, grid_y);
    
    // undraw the previous table and create a new one to edit
    gtk_container_remove(GTK_CONTAINER(window), fixed);
    table = gtk_table_new(8, 8, TRUE);
    gtk_widget_set_size_request(table, BOARD_WIDTH, BOARD_HEIGHT);
    
    
    if (click1_x == 8)
    { // if first click on the board, needs to check for players piece
        Piece = Asset->board[grid_x+8*grid_y];
        if((Piece)&&((Asset->team == Piece->Color)||(Asset->team == 3))){ //
        click1_x = grid_x;
        click1_y = grid_y;

       // printf("startx = %d, starty = %d\n", click1_x, click1_y);
       // printf("_endx = %d, _endy = %d\n", click2_x, click2_y);
        }
    }
    else if ((click2_x == 8))
    { // if second click after first click on a piece, needs to check if legal before displaying
        click2_x = grid_x;
        click2_y = grid_y;
        //printf("endx = %d, endy = %d\n", click2_x, click2_y);
        if (click1_x >7 || click1_y >7 || click2_x >7 || click2_y >7){
            printf("\nThis move is not legal!\n\n");
        }
        else{
            // Get piece pointer for the given input
            Piece = Asset->board[click1_x+8*click1_y];
            if(Asset->team == 3){             // if user has selected PVP board
                color = Piece->Color;
            }
            else{                             // use team color chosen by player
                color = Asset->team;
            }
            
            // execute the input as a move and checks legality
            int moved = MovePiece(Asset->board, Piece, click1_x, click1_y, click2_x, click2_y, Asset->pastmoves, color, 0);
            
            //means move was legal
            if (moved == 0) {
                // make AI move after player moves
                if(Asset->team != 3){
                    if (make_ai_move(Asset)) {
                        printf("AI in checkmate!\n");
                    } 
                }
            }
            //moved = 3 means checkmate
            else if (moved == 3) {
                printf("You are in checkmate!\n");
            }
        }
        // reset click coordinates for next move input
        click1_x = click1_y = click2_x = click2_y = 8;
    }
    // populate the GTK Table and print the board for the user
    DrawBoard(Asset);
    fixed = gtk_fixed_new();
    gtk_fixed_put(GTK_FIXED(fixed), table, 0, 0);
    gtk_container_add(GTK_CONTAINER(window), fixed);

    gtk_widget_show_all(window);

    return TRUE;
}
