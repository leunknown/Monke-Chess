#include "Board.h"
#include <stdio.h>
#include <stdlib.h>

#define BOARDSIZE 8
#define BOARDLENGTH 64

#include <assert.h>
#include <stdio.h>
    
//alloc board memory
PIECE** CreateBoard(void) {
    PIECE* array[BOARDLENGTH];
    PIECE** Board = malloc(sizeof(array));
    if (!Board) {
        perror("ran out of memory!\n");
        exit(11);
    }
    for (int i = 0; i < 64; i++){
        Board[i] = NULL;
    }

    //creating white pawns
    for (int i = 0; i < BOARDSIZE; i++) {
        Board[8 + i] = CreatePiece(white, pawn);    // [1][i]
    }
    //add white rooks
    Board[0] = CreatePiece(white, rook); // [0][0]
    Board[7]= CreatePiece(white, rook); // [0][BOARDSIZE - 1]
    //add white knights
    Board[1] = CreatePiece(white, knight);  // [0][1]
    Board[6] = CreatePiece(white, knight);  // [0][BOARDSIZE - 2]
    //add white bishop
    Board[2] = CreatePiece(white, bishop);  // [0][2]
    Board[5] = CreatePiece(white, bishop);  // [0][BOARDSIZE - 3]
    //add white king/queen
    Board[3] = CreatePiece(white, queen);   // [0][3]
    Board[4] = CreatePiece(white, king);    // [0][BOARDSIZE - 4]

    //creating black pawns
    for(int j = 0; j < BOARDSIZE; j++) {
        Board[48 + j] = CreatePiece(black, pawn);
    }
    //add black rooks
    Board[56] = CreatePiece(black, rook); // [BOARDSIZE - 1][0]
    Board[63] = CreatePiece(black, rook); // [BOARDSIZE - 1][BOARDSIZE - 1]
    //add black knights
    Board[57] = CreatePiece(black, knight);   // [BOARDSIZE - 1][1]
    Board[62] = CreatePiece(black, knight);   // [BOARDSIZE - 1][BOARDSIZE - 2]
    //add black bishop
    Board[58] = CreatePiece(black, bishop);   // [BOARDSIZE - 1][2]
    Board[61] = CreatePiece(black, bishop);   // [BOARDSIZE - 1][BOARDSIZE - 3]
    //add black king/queen
    Board[59] = CreatePiece(black, queen);    // [BOARDSIZE - 1][3]
    Board[60] = CreatePiece(black, king); // [BOARDSIZE - 1][BOARDSIZE - 4]

    return Board;
}

//free board and all pieces on it
void DeleteBoard(PIECE** board) {
    assert(board);
    for (int i = 0; i < BOARDLENGTH; i++) {
        if(board[i]) {
            DeletePiece(board[i]);
            board[i] = NULL;
        }
    }

    free(board);
    return;
}

// Check if a king is in check
int InCheck( PIECE** Board, Colors turnColor){
    int kingx, kingy;
    int counter = 1;
        // Increments through the entire board to find if king is in check
        for (int i = 0; i < 8; i++){
            for (int j = 0; j < 8; j++){
                //Finds the king of whoever's turn it is (ex. if black, then find black king)
                if ((Board[i+8*j] != NULL) && (Board[i+8*j]->PieceType == king) && (Board[i+8*j]->Color == turnColor)){
                    kingx = i;
                    kingy = j;
                }
            }
        }

    //This is the start to see if the king is in check. This is optimized by finding
    //if the king can reach a specific piece given that movement. For example, the king 
    //will check possible squares it can go to assuming it's a queen. If the king can reach
    //a queen of the opposite color, then this king is in check. 

    //SEGMENT: QUEEN AND ROOK
    //This segment checks the horizontal and vertical movements of the queen and rook
    //and sees if the king of opposite color is put into check.

    for (counter = 1; counter < 8; counter++) {
    //vertical check upward
        if (kingy + counter < 8) {       
            if (Board[kingx + (8 * (kingy + counter))]) {
                // If the first piece we check is a queen or rook that is the opposite color, return is in check
                if (((Board[kingx + (8 * (kingy + counter))]->PieceType == queen) &&
                    (Board[kingx + (8 * (kingy + counter))]->Color != turnColor)) ||
                    ((Board[kingx + (8 * (kingy + counter))]->PieceType == rook) &&
                    (Board[kingx + (8 * (kingy + counter))]->Color != turnColor))) {
                        return 1;
                    }
                break; //break for loop if we run into another piece 
            }
        }
    }

    for (counter = 1; counter < 8; counter++) {
                //vertical check downward
        if (kingy - counter >= 0) {
            if (Board[kingx + (8 * (kingy - counter))]) {
                // If the first piece we check is a queen or rook that is the opposite color, return is in check
                if(((Board[kingx + (8 * (kingy - counter))]->PieceType == queen) &&
                    (Board[kingx + (8 * (kingy - counter))]->Color != turnColor)) ||
                    ((Board[kingx + (8 * (kingy - counter))]->PieceType == rook) &&
                    (Board[kingx + (8 * (kingy - counter))]->Color != turnColor))){
                        return 1;
                    }
                break; //break for loop if we run into another piece
            }
        }
    }

    for (counter = 1; counter < 8; counter++) {
                //horizontal check right
        if (kingx + counter < 8) {
            if (Board[(kingx + counter) + 8*kingy]) {
                // If the first piece we check is a queen or rook that is the opposite color, return is in check
                if(((Board[(kingx + counter) + (8 * kingy)]->PieceType == queen) &&
                    (Board[(kingx + counter) + (8 * kingy)]->Color != turnColor)) ||
                    ((Board[(kingx + counter) + (8 * kingy)]->PieceType == rook) &&
                    (Board[(kingx + counter) + (8 * kingy)]->Color != turnColor))) {
                        return 1;
                    }
                break; //break for loop if we run into another piece
            }
        }
    }

    for (counter = 1; counter < 8; counter++) {
                //horizontal check left
        if (kingy - counter >= 0) {
            if (Board[(kingx - counter) + (8 * kingy)]) {
                // If the first piece we check is a queen or rook that is the opposite color, return is in check
                if(((Board[(kingx - counter) + (8 * kingy)]->PieceType == queen) &&
                    (Board[(kingx - counter) + (8 * kingy)]->Color != turnColor)) ||
                    ((Board[(kingx - counter) + (8 * kingy)]->PieceType == rook) &&
                    (Board[(kingx - counter) + (8 * kingy)]->Color != turnColor))) {
                        return 1;
                    }
                break; //break for loop if we run into another piece
            }
        }
    }

    //SEGMENT: QUEEN AND BISHOP
    //This checks the diagonals for attacks on the king by queens and bishops
    //of the opposite color.
    for (counter = 1; counter < 8; counter++) {
                //diagonal check up and right
        if (kingx + counter < 8 && kingy + counter < 8) {
            if (Board[(kingx + counter) + (8 * (kingy + counter))]) {
                // If the first piece we check is a queen or bishop that is the opposite color, return is in check
                if(((Board[(kingx + counter) + (8 * (kingy + counter))]->PieceType == queen) &&
                    (Board[(kingx + counter) + (8 * (kingy + counter))]->Color != turnColor)) ||
                    ((Board[(kingx + counter) + (8 * (kingy + counter))]->PieceType == bishop) &&
                    (Board[(kingx + counter) + (8 * (kingy + counter))]->Color != turnColor))) {
                        return 1;
                    }
                break; //break for loop if we run into another piece
            }
        }
    }

    for (counter = 1; counter < 8; counter++) {
                //diagonal check up and left
        if (kingx - counter >= 0 && kingy + counter < 8) {
            if (Board[(kingx - counter) + (8 * (kingy + counter))]) {
                // If the first piece we check is a queen or bishop that is the opposite color, return 1 if in check
                if(((Board[(kingx - counter) + (8 * (kingy + counter))]->PieceType == queen) &&
                    (Board[(kingx - counter) + (8 * (kingy + counter))]->Color != turnColor)) ||
                    ((Board[(kingx - counter) + (8 * (kingy + counter))]->PieceType == bishop) &&
                    (Board[(kingx - counter) + (8 * (kingy + counter))]->Color != turnColor))) {
                        return 1;
                    }
                break; //break for loop if we run into another piece
            }
        }
    }

    for (counter = 1; counter < 8; counter++) {
                //diagonal check down and left
        if (kingx - counter >= 0 && kingy - counter >= 0) {
            if (Board[(kingx - counter) + (8 * (kingy - counter))]) {
                // If the first piece we check is a queen or bishop that is the opposite color, return 1 if in check
                if(((Board[(kingx - counter) + (8 * (kingy - counter))]->PieceType == queen) &&
                    (Board[(kingx - counter) + (8 * (kingy - counter))]->Color != turnColor)) ||
                    ((Board[(kingx - counter) + (8 * (kingy - counter))]->PieceType == bishop) &&
                    (Board[(kingx - counter) + (8 * (kingy - counter))]->Color != turnColor))) {
                        return 1;
                    }
                break; //break for loop if we run into another piece
            }
        }
    }

    for (counter = 1; counter < 8; counter++) {
                //diagonal check down and right
        if (kingx + counter < 8 && kingy - counter >= 0) {
            if (Board[(kingx + counter) + (8 * (kingy - counter))]) {
                // If the first piece we check is a queen or bishop that is the opposite color, return 1 if in check
                if(((Board[(kingx + counter) + (8 * (kingy - counter))]->PieceType == queen) &&
                    (Board[(kingx + counter) + (8 * (kingy - counter))]->Color != turnColor)) ||
                    ((Board[(kingx + counter) + (8 * (kingy - counter))]->PieceType == bishop) &&
                    (Board[(kingx + counter) + (8 * (kingy - counter))]->Color != turnColor))) {
                        return 1;
                    }
                break; //break for loop if we run into another piece
            }
        }
    }
    //sEGMENT: KNIGHT
    //This set of code checks if a knight is attacking the king
    //using the same idea as previously. We start from the perspective of
    //the king and then use "knight moves" to check if there are any enemy
    //knights in the vicinity.

    //check right 1 square and up 2 squares for knight
    if (kingx + 1 < 8 && kingy + 2 < 8) {
        //If there exists a piece, continue
        if (Board[(kingx + 1) + (8 * (kingy + 2))]){
            if((Board[(kingx + 1) + (8 * (kingy + 2))]->PieceType == knight) &&
            (Board[(kingx + 1) + (8 * (kingy + 2))]->Color != turnColor)){
                return 1;
            }
        }
    }
    //check left 1 square and up 2 squares for knight
    if (kingx - 1 >= 0 && kingy + 2 < 8) {
        //If there exists a piece, continue
        if(Board[(kingx - 1) + (8 * (kingy + 2))]){
            if((Board[(kingx - 1) + (8 * (kingy + 2))]->PieceType == knight) &&
            (Board[(kingx - 1) + (8 * (kingy + 2))]->Color != turnColor)){
                return 1;
            }
        }

    }
    //check left 1 square and down 2 squares for knight
    if (kingx - 1 >= 0 && kingy - 2 >= 0) {
        //If there exists a piece, continue
        if (Board[(kingx - 1) + (8 * (kingy - 2))]){
            if((Board[(kingx - 1) + (8 * (kingy - 2))]->PieceType == knight) &&
            (Board[(kingx - 1) + (8 * (kingy - 2))]->Color != turnColor)){
                return 1;
            }
        }
    }
    //check right 1 square and down 2 squares for knight
    if (kingx + 1 < 8 && kingy - 2 >= 0) {
        //If there exists a piece, continue
        if(Board[(kingx + 1) + (8 * (kingy - 2))]){
            if((Board[(kingx + 1) + (8 * (kingy - 2))]->PieceType == knight) &&
            (Board[(kingx + 1) + (8 * (kingy - 2))]->Color != turnColor)){
                return 1;
            }
        }
    }
    //check right 2 squares and up 1 square for knight
    if (kingx + 2 < 8 && kingy + 1 < 8) {
        //If there exists a piece, continue
        if(Board[(kingx + 2) + (8 * (kingy + 1))]){
            if((Board[(kingx + 2) + (8 * (kingy + 1))]->PieceType == knight) &&
            (Board[(kingx + 2) + (8 * (kingy + 1))]->Color != turnColor)){
                return 1;
            }
        }
    }
    //check right 2 squares and down 1 square for knight
    if (kingx + 2 < 8 && kingy - 1 >= 0) {
        //If there exists a piece, continue
        if(Board[(kingx + 2) + (8 * (kingy - 1))]){
            if((Board[(kingx + 2) + (8 * (kingy - 1))]->PieceType == knight) &&
            (Board[(kingx + 2) + (8 * (kingy - 1))]->Color != turnColor)){
                return 1;
            }  
        }
        
    }
    //check left 2 squares and up 1 square for knight
    if (kingx - 2 >= 0 && kingy + 1 < 8) {
        //If there exists a piece, continue
        if(Board[(kingx - 2) + (8 * (kingy + 1))]){
           if((Board[(kingx - 2) + (8 * (kingy + 1))]->PieceType == knight) &&
           (Board[(kingx - 2) + (8 * (kingy + 1))]->Color != turnColor)){
               return 1;
           } 
        }
        
    }
    //check left 2 squares and down 1 square for knight
    if (kingx - 2 >= 0 && kingy - 1 >= 0) {
        //If there exists a piece, continue
        if(Board[(kingx - 2) + (8 * (kingy - 1))]){
            if((Board[(kingx - 2) + (8 * (kingy - 1))]->PieceType == knight) &&
            (Board[(kingx - 2) + (8 * (kingy - 1))]->Color != turnColor)){
                return 1;
            } 
        }
        
    }
    //SEGMENT: PAWN
    //This checks for pawn attacks onto the king. There are attacks for
    //black pawns onto the white king and white pawns onto the black king.

    // Check for pawn above and right of king (check for white by black) 
    if (kingx + 1 < 8 && kingy + 1 < 8) {
        //If there exists a piece, continue
        if (Board[(kingx + 1) + (8 * (kingy + 1))]){
            if ((Board[(kingx + 1) + (8 * (kingy + 1))]->PieceType == pawn) &&
                (Board[(kingx + 1) + (8 * (kingy + 1))]->Color != turnColor) &&
                (Board[(kingx + 1) + (8 * (kingy + 1))]->Color == black)){
                return 1;
            } 
        }
    }
    // Check for pawn attack from up and left of king (check for white by black)
    if (kingx - 1 >= 0 && kingy + 1 < 8) {
        //If there exists a piece, continue
        if(Board[(kingx - 1) + (8 * (kingy + 1))]){
            if ((Board[(kingx - 1) + (8 * (kingy + 1))]->PieceType == pawn) &&
                (Board[(kingx - 1) + (8 * (kingy + 1))]->Color != turnColor) &&
                (Board[(kingx - 1) + (8 * (kingy + 1))]->Color == black)){
                return 1;
            } 
        }
    }

    // Check for pawn below and right of king (check for black by white) 
    if (kingx + 1 < 8 && kingy - 1 < 8) {
        //If there exists a piece, continue
        if (Board[(kingx + 1) + (8 * (kingy - 1))]){
            if ((Board[(kingx + 1) + (8 * (kingy - 1))]->PieceType == pawn) &&
                (Board[(kingx + 1) + (8 * (kingy - 1))]->Color != turnColor) &&
                (Board[(kingx + 1) + (8 * (kingy - 1))]->Color == white)){
                return 1;
            } 
        }
    }

    // Check for pawn below and left of king (check for black by white) 
    if (kingx - 1 < 8 && kingy - 1 < 8) {
        if (Board[(kingx - 1) + (8 * (kingy - 1))]){
            if ((Board[(kingx - 1) + (8 * (kingy - 1))]->PieceType == pawn) &&
                (Board[(kingx - 1) + (8 * (kingy - 1))]->Color != turnColor) &&
                (Board[(kingx - 1) + (8 * (kingy - 1))]->Color == white)){
                return 1;
            } 
        }
    }

    //SEGMENT: KING
    //This section prevents the king from getting within 1 square of the
    //other king moreso than letting one king from checking another.

    // check up
    if (kingy + 1 < 8 && Board[kingx + 8 * (kingy + 1)]) {
        if ((Board[kingx + 8 * (kingy + 1)]->PieceType == king) &&
            (Board[kingx + 8 * (kingy + 1)]->Color != turnColor)){
                return 1;
            }
    }
    //check down
    if (kingy - 1 >= 0 && Board[kingx + 8 * (kingy - 1)]) {
        if ((Board[kingx + 8 * (kingy - 1)]->PieceType == king) &&
            (Board[kingx + 8 * (kingy - 1)]->Color != turnColor)){
                return 1;
            }
    }
    //check right
    if (kingx + 1 < 8 && Board[(kingx + 1) + 8 * kingy]) {
        if ((Board[(kingx + 1) + 8 * kingy]->PieceType == king) &&
            (Board[(kingx + 1) + 8 * kingy]->Color != turnColor)){
                return 1;
            }
    }
    //check left
    if (kingx - 1 >= 0 && Board[(kingx - 1) + 8 * kingy]) {
        if ((Board[(kingx - 1) + 8 * kingy]->PieceType == king) &&
            (Board[(kingx - 1) + 8 * kingy]->Color != turnColor)){
                return 1;
            }
    }
    //check up and right
    if (kingx + 1 < 8 && kingy + 1 < 8 && Board[(kingx + 1) + 8 * (kingy + 1)]) {
        if ((Board[(kingx + 1) + 8 * (kingy + 1)]->PieceType == king) &&
            (Board[(kingx + 1) + 8 * (kingy + 1)]->Color != turnColor)){
                return 1;
            }
    }
    //check up and left
    if (kingx - 1 >= 0 && kingy + 1 < 8 && Board[(kingx - 1) + 8 * (kingy + 1)]) {
        if ((Board[(kingx - 1) + 8 * (kingy + 1)]->PieceType == king) &&
            (Board[(kingx - 1) + 8 * (kingy + 1)]->Color != turnColor)){
                return 1;
            }
    }
    //check down and left
    if (kingx - 1 >= 0 && kingy - 1 >= 0 && Board[(kingx - 1) + 8 * (kingy - 1)]) {
        if ((Board[(kingx - 1) + 8 * (kingy - 1)]->PieceType == king) &&
            (Board[(kingx - 1) + 8 * (kingy - 1)]->Color != turnColor)){
                return 1;
            }
    }
    //check down and right
    if (kingx + 1 < 8 && kingy - 1 >= 0 && Board[(kingx + 1) + 8 * (kingy - 1)]) {
        if ((Board[(kingx + 1) + 8 * (kingy - 1)]->PieceType == king) &&
            (Board[(kingx + 1) + 8 * (kingy - 1)]->Color != turnColor)){
                return 1;
            }
    }

    return 0;
}

// This is the move list which will be used to hold all
// possible moves that are possible for a player in a given board
// returns move list
MOVELIST* PossibleMoves(PIECE** board, PIECE* piece, int startx, int starty, MOVELIST* pastlist){
    //basically the create movelist
    MOVELIST* moveList = NULL;
    moveList = malloc(sizeof(MOVELIST));
    if(!moveList){
        printf("Out of memory for move list! Exiting...");
        exit(10);
    }

    moveList->Length = 0;
    moveList->First = NULL;
    moveList->Last = NULL;
    //end of create move list

    MOVE* tmpMove = NULL;
    int counter = 1;

    //append moves depending on piece type
    switch(piece->PieceType) {
        case queen:
            //continue incrementing counter until you reach the end of the board
            //add moves for every direction
            for (counter = 1; counter < 8; counter++) {
                //move up
                if (starty + counter < 8) {
                    if (board[startx + 8*(starty + counter)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[startx + 8*(starty + counter)]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx, starty + counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move down
                if (starty - counter >= 0) {
                    if (board[startx + 8*(starty - counter)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[startx + 8*(starty - counter)]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move right
                if (startx + counter < 8) {
                    if (board[(startx + counter) + 8*starty] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + counter, starty);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx + counter) + 8*starty]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx + counter, starty);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move left
                if (startx - counter >= 0) {
                    if (board[(startx - counter) + (8 * starty)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - counter, starty);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx - counter) + (8 * starty)]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx - counter, starty);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move up and right
                if (startx + counter < 8 && starty + counter < 8) {
                    if (board[(startx + counter) + (8 * (starty + counter))] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + counter, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx + counter) + (8 * (starty + counter))]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx + counter, starty + counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move up and left
                if (startx - counter >= 0 && starty + counter < 8) {
                    if (board[(startx - counter) + (8 * (starty + counter))] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - counter, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx - counter) + (8 * (starty + counter))]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx - counter, starty + counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move down and left
                if (startx - counter >= 0 && starty - counter >= 0) {
                    if (board[(startx - counter) + (8 * (starty - counter))] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - counter, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx - counter) + (8 * (starty - counter))]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx - counter, starty - counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move down and right
                if (startx + counter < 8 && starty - counter >= 0) {
                    if (board[(startx + counter) + (8 * (starty - counter))] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + counter, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx + counter) + (8 * (starty - counter))]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx + counter, starty - counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            break;
        case rook:
            //add moves for vertical and horizontal direction
            for (counter = 1; counter < 8; counter++) {
                //move up
                if (starty + counter < 8) {
                    if (board[startx + 8*(starty + counter)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[startx + 8*(starty + counter)]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx, starty + counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move down
                if (starty - counter >= 0) {
                    if (board[startx + 8*(starty - counter)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[startx + 8*(starty - counter)]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move right
                if (startx + counter < 8) {
                    if (board[(startx + counter) + 8*starty] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + counter, starty);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx + counter) + 8*starty]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx + counter, starty);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move left
                if (startx - counter >= 0) {
                    if (board[(startx - counter) + (8 * starty)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - counter, starty);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx - counter) + (8 * starty)]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx - counter, starty);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            break;
        case bishop:
            //append moves in diagonal
            for (counter = 1; counter < 8; counter++) {
                //move up and right
                if (startx + counter < 8 && starty + counter < 8) {
                    if (board[(startx + counter) + (8 * (starty + counter))] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + counter, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx + counter) + (8 * (starty + counter))]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx + counter, starty + counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move up and left
                if (startx - counter >= 0 && starty + counter < 8) {
                    if (board[(startx - counter) + (8 * (starty + counter))] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - counter, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx - counter) + (8 * (starty + counter))]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx - counter, starty + counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move down and left
                if (startx - counter >= 0 && starty - counter >= 0) {
                    if (board[(startx - counter) + (8 * (starty - counter))] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - counter, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx - counter) + (8 * (starty - counter))]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx - counter, starty - counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            for (counter = 1; counter < 8; counter++) {
                //move down and right
                if (startx + counter < 8 && starty - counter >= 0) {
                    if (board[(startx + counter) + (8 * (starty - counter))] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + counter, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
                    else {
                        if (piece->Color != board[(startx + counter) + (8 * (starty - counter))]->Color) {
                            tmpMove = CreateMove(piece, startx, starty, startx + counter, starty - counter);
                            AppendMove(moveList, tmpMove);
                        }
                        break; //break for loop if we run into another piece
                    }
                }
            }
            break;
        case knight:
            //move up2 then right1
            if (startx + 1 < 8 && starty + 2 < 8) {
                if (board[(startx + 1) + 8*(starty + 2)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty + 2);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx + 1) + 8*(starty + 2)]->Color) {
                    tmpMove = CreateMove(piece, startx, starty, startx + 1, starty + 2);
                    AppendMove(moveList, tmpMove);
                }
            }
            //move up then left
            if (startx - 1 >= 0 && starty + 2 < 8) {
                if (board[(startx - 1) + 8*(starty + 2)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty + 2);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx - 1) + 8*(starty + 2)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty + 2);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move down then left
            if (startx - 1 >= 0 && starty - 2 >= 0) {
                if (board[(startx - 1) + 8*(starty - 2)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty - 2);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx - 1) + 8*(starty - 2)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty - 2);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move down then right
            if (startx + 1 < 8 && starty - 2 >= 0) {
                if (board[(startx + 1) + 8*(starty - 2)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty - 2);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx + 1) + 8*(starty - 2)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty - 2);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move right then up
            if (startx + 2 < 8 && starty + 1 < 8) {
                if (board[(startx + 2) + 8*(starty + 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 2, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx + 2) + 8*(starty + 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 2, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move right then down
            if (startx + 2 < 8 && starty - 1 >= 0) {
                if (board[(startx + 2) + 8*(starty - 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 2, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx + 2) + 8*(starty - 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 2, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move left then up
            if (startx - 2 >= 0 && starty + 1 < 8) {
                if (board[(startx - 2) + 8*(starty + 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 2, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx - 2) + 8*(starty + 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 2, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move left then down
            if (startx - 2 >= 0 && starty - 1 >= 0) {
                if (board[(startx - 2) + 8*(starty - 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 2, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx - 2) + 8*(starty - 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 2, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
            }
            break;
        case king:
            //only add moves for counter = 1
            //any direction
            //move up
            if (starty + counter < 8) {
                if (board[(startx) + 8*(starty + 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[startx + 8*(starty + 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move down
            if (starty - counter >= 0) {
                if (board[(startx) + 8*(starty - 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[startx + 8*(starty - 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move right
            if (startx + counter < 8) {
                if (board[(startx + 1) + 8*(starty)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx + 1) + 8*starty]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move left
            if (startx - counter >= 0) {
                if (board[(startx - 1) + 8*(starty)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx - 1) + 8*(starty)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move up and right
            if (startx + counter < 8 && starty + counter < 8) {
                if (board[(startx + 1) + 8*(starty + 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx + 1) + 8*(starty + 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move up and left
            if (startx - counter >= 0 && starty + counter < 8) {
                if (board[(startx - 1) + 8*(starty + 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx - 1) + 8*(starty + 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //move down and left
            if (startx - counter >= 0 && starty - counter >= 0) {
                if (board[(startx - 1) + 8*(starty - 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx - 1 ) + 8*(starty - 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty - 1);
                        AppendMove(moveList, tmpMove); 
                }
            }
            //move down and right
            if (startx + counter < 8 && starty - counter >= 0) {
                if (board[(startx + 1) + 8*(starty - 1)] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
                else if (piece->Color != board[(startx + 1) + 8*(starty - 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //castling white
            if (piece->Color == white) {
                //white castling left
                if (piece->HasMoved    == false &&
                    board[0]                    &&
                    board[0]->HasMoved == false &&
                    board[1] == NULL            &&
                    board[2] == NULL            &&
                    board[3] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 2, starty);
                        AppendMove(moveList, tmpMove);
                    }
                //white castling right
                if (piece->HasMoved    == false &&
                    board[7]                    &&
                    board[7]->HasMoved == false &&
                    board[6] == NULL            &&
                    board[5] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 2, starty);
                        AppendMove(moveList, tmpMove);
                    }
            }
            //castling black
            else {
                //black castling left
                if (piece->HasMoved    == false &&
                    board[7*8 + 0]                    &&
                    board[7*8 + 0]->HasMoved == false &&
                    board[7*8 + 1] == NULL            &&
                    board[7*8 + 2] == NULL            &&
                    board[7*8 + 3] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 2, starty);
                        AppendMove(moveList, tmpMove);
                    }
                //black castling right
                if (piece->HasMoved    == false &&
                    board[7*8 + 7]                    &&
                    board[7*8 + 7]->HasMoved == false &&
                    board[7*8 + 6] == NULL            &&
                    board[7*8 + 5] == NULL) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 2, starty);
                        AppendMove(moveList, tmpMove);
                    }
            }
            break;
        case pawn:
            //white
            if (piece->Color == white) {
                //move up 1
                if (starty + 1 < 8) {
                    //if space in front is empty
                    if (!board[startx + (8*(starty + 1))]) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
                }
                //move up 2
                if (starty + 2 < 8 && !(piece->HasMoved)) {
                    if (!board[startx + (8*(starty + 2))] && !board[startx + (8*(starty + 1))]) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty + 2);
                        AppendMove(moveList, tmpMove);
                    }
                }
                //capture right
                if (startx + 1 < 8 && starty + 1 < 8 && board[startx + 1 + (starty + 1)*8]) {
                    if (piece->Color != board[(startx + 1) + 8*(starty + 1)]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty + 1);
                        AppendMove(moveList, tmpMove);
                    }
                }
                //capture left
                if (startx - 1 >= 0 && starty + 1 < 8 && board[startx - 1 + (starty + 1)*8]) {
                    if (piece->Color != board[startx - 1 + (starty + 1)*8]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty + counter);
                        AppendMove(moveList, tmpMove);
                    }
                }
                //en passant left (up 2 left 1)
                if(pastlist->Last){
                    if (pastlist->Last->move->piece->PieceType == pawn && abs((pastlist->Last->move->starty) - (pastlist->Last->move->endy)) == 2 && abs((pastlist->Last->move->startx) - (pastlist->Last->move->endx)) == 0){
                        if (startx - 1 >= 0 && starty + 1 < 8 && board[startx - 1 + (starty + 0)*8]) {
                            if (piece->Color != board[startx - 1 + (starty + 0)*8]->Color) {
                                tmpMove = CreateMove(piece, startx, starty, startx - 1, starty + counter);
                                AppendMove(moveList, tmpMove);
                            }
                        }
                    }
                }
                //en passant right
                if(pastlist->Last){
                    if (pastlist->Last->move->piece->PieceType == pawn && abs((pastlist->Last->move->starty) - (pastlist->Last->move->endy)) == 2 && abs((pastlist->Last->move->startx) - (pastlist->Last->move->endx)) == 0){
                        if (startx + 1 >= 0 && starty + 1 < 8 && board[startx + 1 + (starty + 0)*8]) {
                            if (piece->Color != board[startx + 1 + (starty + 0)*8]->Color) {
                                tmpMove = CreateMove(piece, startx, starty, startx + 1, starty + counter);
                                AppendMove(moveList, tmpMove);
                            }
                        }
                    }
                }

            }
            //black
            else {
                //move up 1
                if (starty - 1 >= 0) {
                    if (!board[startx + (8*(starty - 1))]) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
                }
                //move up 2
                if (starty - 2 >= 0 && !(piece->HasMoved)) {
                    if (!board[startx + (8*(starty - 2))] && !board[startx + (8*(starty - 1))]) {
                        tmpMove = CreateMove(piece, startx, starty, startx, starty - 2);
                        AppendMove(moveList, tmpMove);
                    }
                }
                //capture right
                if (startx + 1 < 8 && starty - 1 >= 0 && board[startx + 1 + (starty - 1)*8]) {
                    if (piece->Color != board[startx + 1 + (starty - 1)*8]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx + 1, starty - counter);
                        AppendMove(moveList, tmpMove);
                    }
                }
                //capture left
                if (startx - 1 >= 0 && starty - 1 >= 0 && board[startx - 1 + (starty - 1)*8]) {
                    if (piece->Color != board[startx - 1 + (starty - 1)*8]->Color) {
                        tmpMove = CreateMove(piece, startx, starty, startx - 1, starty - 1);
                        AppendMove(moveList, tmpMove);
                    }
                }
                //en passant left (up 2 left 1)
                if(pastlist->Last){
                    if (pastlist->Last->move->piece->PieceType == pawn && abs((pastlist->Last->move->starty) - (pastlist->Last->move->endy)) == 2 && abs((pastlist->Last->move->startx) - (pastlist->Last->move->endx)) == 0){
                        if (startx - 1 >= 0 && starty - 1 < 8 && board[startx - 1 + (starty + 0)*8]) {
                            if (piece->Color != board[startx - 1 + (starty + 0)*8]->Color) {
                                tmpMove = CreateMove(piece, startx, starty, startx - 1, starty - counter);
                                AppendMove(moveList, tmpMove);
                            }
                        }
                    }
                }
                //en passant right
                if(pastlist->Last){
                    if (pastlist->Last->move->piece->PieceType == pawn && abs((pastlist->Last->move->starty) - (pastlist->Last->move->endy)) == 2 && abs((pastlist->Last->move->startx) - (pastlist->Last->move->endx)) == 0){
                        if (startx + 1 >= 0 && starty - 1 < 8 && board[startx + 1 + (starty + 0)*8]) {
                            if (piece->Color != board[startx + 1 + (starty + 0)*8]->Color) {
                                tmpMove = CreateMove(piece, startx, starty, startx + 1, starty - counter);
                                AppendMove(moveList, tmpMove);
                            }
                        }
                    }
                }
            }
            break;
        default:
            break;
    } //switch

    return moveList;
}


//create move structs to add to list
MOVE* CreateMove(PIECE* piece, unsigned int startx, unsigned int starty, unsigned int endx, unsigned int endy){
    MOVE* move = NULL;
    move = malloc(sizeof(MOVE));

    if(!move){
        printf("Move not created! Exiting...");
        exit(11);
    }

    move->piece = piece;
    move->startx = startx;
    move->starty = starty;
    move->endx = endx;
    move->endy = endy;

    return move;
}

//check if move is legal using movelist of all possible moves
//if move is legal return 1
//if illegal return 0
//if in check, return 2
int LegalMoveCheck(PIECE** Board, MOVE* move, MOVELIST* pastlist, Colors turnColor) {
    assert(Board);
    assert(move);
    MOVELIST* moveList = NULL;
    moveList = PossibleMoves(Board, move->piece, move->startx, move->starty,pastlist);
    MOVEENTRY* entry = moveList->First;
    int legal = 0;

    //copy of board
    PIECE* tmpboard[64];
    //check
    for (int i = 0; i < 64; i++) {
        tmpboard[i] = Board[i]; 
    }
    //move on tmp board
    tmpboard[move->endx + 8*move->endy] = tmpboard[move->startx + 8*move->starty];
    tmpboard[move->startx + 8*move->starty] = NULL;
    //if still in check after move
    if (InCheck(tmpboard, turnColor)) {
        printf("\nin check\n");
        return 2;
    }
    
    //check if legal move
    while(entry) {
        //basically, if our move is the exact same as one in our possible moves list
        if ((move->starty == entry->move->starty) && 
            (move->startx == entry->move->startx) && 
            (move->endy == entry->move->endy)     && 
            (move->endx == entry->move->endx)) {
                legal = 1;
            }
        entry = entry->next;
    }
    DeleteMoveList(moveList);
    //if our move is not in the list return 0
    return legal;
}

// Adds the move to move log, chessLog.txt

void AppendChessAction(unsigned int startx, unsigned int starty, unsigned int endx, unsigned int endy, unsigned int taken){
    FILE *file;

    file = fopen("./chessLog.txt","a");
    if (file == NULL){
        printf("Unable to open chess log!\n");
        exit(1);
    }
    // If a piece was taken, use this prompt. Else, we print a movement of a piece.
    if (taken) {
        fprintf(file, "%c%d takes %c%d\n", startx + 97, starty + 1, endx + 97, endy + 1);
    }
    else {
        fprintf(file, "%c%d goes to %c%d\n", startx + 97, starty + 1, endx + 97, endy + 1);
    }
    fclose(file);

}

//move and capture in the array (FOR PLAYER)

int MovePiece(PIECE** board, PIECE* piece, unsigned int startx, unsigned int starty, unsigned int endx, unsigned int endy,MOVELIST* pastlist, Colors turnColor, int AIflag){
    PIECE* movePiece = NULL;
    MOVE* move = NULL;
    unsigned int taken = 0;
    move = CreateMove(piece, startx, starty, endx, endy);
    int legal = LegalMoveCheck(board, move, pastlist, turnColor);
    DeleteMove(move);

    //if illegal move
    if (legal == 0) {
        printf("\nThis move is not legal!\n\n");
        return 2;
    }
    
    //if in check
    if (legal == 2) {
        printf("\nThis move is not legal! in check\n\n");
        //copy of board
        PIECE* tmpboard[64];
        MOVELIST* checklist = NULL;
        MOVEENTRY* nextentry = NULL;
        //for every piece
        for (int i; i < 64; i++) {
            //if piece exists and is same color
            if (board[i] && board[i]->Color == turnColor) {
                //find all moves for that piece
                checklist = PossibleMoves(board, board[i], i % 8, i / 8, pastlist);
                nextentry = checklist->First;
                //for every move of a given piece
                while (nextentry) {
                    //copy board
                    for (int i = 0; i < 64; i++) {
                        tmpboard[i] = board[i]; 
                    }
                    //move on tmp board
                    tmpboard[nextentry->move->endx + 8*nextentry->move->endy] = tmpboard[nextentry->move->startx + 8*nextentry->move->starty];
                    tmpboard[nextentry->move->startx + 8*nextentry->move->starty] = NULL;
                    //if in check after move
                    if (InCheck(tmpboard, turnColor)) {
                        //continue
                        printf("move does not take out of check\n");
                        nextentry = nextentry->next;
                    }
                    //else if not in check
                    else {
                        printf("there is a move that take it out of check\n");
                        DeleteMoveList(checklist);
                        return 2;
                    }
                    
                }
                //delete movelist
                DeleteMoveList(checklist);
            }
            //go for next piece
        }
        //if you have no valid moves, quit
        printf("you are in checkmate\n");
        return 3;
    }
    
    else {
        //if the is a piece at the end point, delete it
        if(board[(endx) + (endy * 8)]) {
            printf("\n%d%d is taken by %d%d\n\n", endx + 1, endy + 1, startx + 1, starty + 1);
            taken = 1;
            DeletePiece(board[(endx) + (endy * 8)]);
        }
        //white special moves
        if (piece->Color == white) {
            //white castling left (move rook)
            if (piece->PieceType == king && endx == 2 && endy == 0) {
                board[3] = board[0];
                board[0] = NULL;
            }
            //white castling right (move rook)
            if (piece->PieceType == king && endx == 6 && endy == 0) {
                board[5] = board[7];
                board[7] = NULL;
            }
            // white promotion
            if (piece->PieceType == pawn && endy == 7){
                PromotePiece(board[startx + (starty * 8)], AIflag);
            }
            //en passant left 
            if(pastlist->Last){
                if (pastlist->Last->move->piece->PieceType == pawn && abs((pastlist->Last->move->starty) - (pastlist->Last->move->endy)) == 2 && abs((pastlist->Last->move->startx) - (pastlist->Last->move->endx)) == 0){
                    if (startx - 1 >= 0 && starty + 1 < 8 && board[startx - 1 + (starty + 0)*8]) {
                        if (piece->Color != board[startx - 1 + (starty + 0)*8]->Color) {
                            if(board[endx + ((endy-1) * 8)]->PieceType == pawn){
                                DeletePiece(board[(endx) + ((endy-1) * 8)]);
                                board[(endx) + (endy-1) * 8] = NULL;
                                printf("\n%d%d is taken by %d%d\n\n", endx + 1, endy + 1, startx + 1, starty + 1);
                                taken = 1;
                            }
                        }
                    }
                }
            }
            //en passant right
            if(pastlist->Last){
                if (pastlist->Last->move->piece->PieceType == pawn && abs((pastlist->Last->move->starty) - (pastlist->Last->move->endy)) == 2 && abs((pastlist->Last->move->startx) - (pastlist->Last->move->endx)) == 0){
                    if (startx + 1 >= 0 && starty + 1 < 8 && board[startx + 1 + (starty + 0)*8]) {
                        if (piece->Color != board[startx + 1 + (starty + 0)*8]->Color) {    //check opp color
                            if(board[endx + ((endy-1) * 8)]->PieceType == pawn){            // checks if piece on athe right is pawn (enpassant)
                                DeletePiece(board[(endx) + ((endy-1) * 8)]);
                                board[(endx) + (endy-1) * 8] = NULL;
                                printf("\n%d%d is taken by %d%d\n\n", endx + 1, endy + 1, startx + 1, starty + 1);
                                taken = 1;
                            }
                        }
                    }
                }
            } 


        }
        //black special moves
        else if (piece->Color == black) {
            //black castling left (move rook)
            if (piece->PieceType == king && endx == 2 && endy == 7) {
                board[7*8 + 3] = board[7*8 + 0];
                board[7*8 + 0] = NULL;
            }
            //black castling right (move rook)
            if (piece->PieceType == king && endx == 6 && endy == 7) {
                board[7*8 + 5] = board[7*8 + 7];
                board[7*8 + 7] = NULL;
            }

            if (piece->PieceType == pawn && endy == 0){
                PromotePiece(board[startx + (starty * 8)], AIflag);
            }
            //en passant left 
            if(pastlist->Last){
                if (pastlist->Last->move->piece->PieceType == pawn && abs((pastlist->Last->move->starty) - (pastlist->Last->move->endy)) == 2 && abs((pastlist->Last->move->startx) - (pastlist->Last->move->endx)) == 0){
                    if (startx - 1 >= 0 && starty - 1 < 8 && board[startx - 1 + (starty + 0)*8]) {
                        if (piece->Color != board[startx - 1 + (starty + 0)*8]->Color) {
                            if(board[endx + ((endy+1) * 8)]->PieceType == pawn){
                                DeletePiece(board[(endx) + ((endy+1) * 8)]);
                                board[(endx) + (endy+1) * 8] = NULL;
                                printf("\n%d%d is taken by %d%d\n\n", endx + 1, endy + 1, startx + 1, starty + 1);
                                taken = 1;
                            }
                        }
                    }
                }
            }
            //en passant right
            if(pastlist->Last){
                if (pastlist->Last->move->piece->PieceType == pawn && abs((pastlist->Last->move->starty) - (pastlist->Last->move->endy)) == 2 && abs((pastlist->Last->move->startx) - (pastlist->Last->move->endx)) == 0){
                    if (startx + 1 >= 0 && starty - 1 < 8 && board[startx + 1 + (starty + 0)*8]) {
                        if (piece->Color != board[startx + 1 + (starty + 0)*8]->Color) {    //check opp color
                            if(board[endx + ((endy+1) * 8)]->PieceType == pawn){            // checks if piece on athe right is pawn (enpassant)
                                DeletePiece(board[(endx) + ((endy+1) * 8)]);
                                board[(endx) + (endy+1) * 8] = NULL;
                                printf("\n%d%d is taken by %d%d\n\n", endx + 1, endy + 1, startx + 1, starty + 1);
                                taken = 1;
                            }
                        }
                    }
                }
            }
        }
        //move start Piece to end position and null start
        move = CreateMove(piece, startx, starty, endx, endy);
        AppendMove(pastlist, move);
        
        movePiece = board[startx + (starty * 8)];
        board[(endx) + (endy * 8)] = movePiece;
        board[startx + (starty * 8)] = NULL;
        //now states that piece has been moved.
        piece->HasMoved = true;

       // gui_move_piece(piece, startx, starty, endy, endy, Asset);
        //Testing for move log
        AppendChessAction(startx, starty, endx, endy , taken);

        
        return 0;
    }
}

//delete move
void DeleteMove(MOVE* move){
    assert(move);
    free(move);
}

/* added by Theo edited by Justin*/
void AppendMove(MOVELIST* moveList, MOVE* move){
    MOVEENTRY* moveEntry; //temp variable m for move.
    assert(moveList);
    assert(move);
    //basically the create move entry
    //alloc entry
    moveEntry = malloc(sizeof(MOVEENTRY));
    if (! moveEntry) {
        perror("Out of memory! AppendMove Aborting...");
	    exit(12);
    }

    moveEntry->list = moveList;
    moveEntry->move = move;
    moveEntry->next = NULL;
    moveEntry->prev = moveList->Last;
    //end of create entry

    if (moveList->Last) {
        moveList->Last->next = moveEntry;
        moveList->Last = moveEntry;
    }
    else {
        moveList->First = moveEntry;
        moveList->Last = moveEntry;
    }
    moveList->Length++;
}

//delete list and entries
void DeleteMoveList(MOVELIST *moveList) {
    assert(moveList);
    MOVEENTRY *entry = NULL;
    MOVEENTRY *nextEntry = NULL;

    entry = moveList->First;

    while(entry) {
        DeleteMove(entry->move);
        nextEntry = entry->next;
        free(entry);
        entry = nextEntry;
    }
    free(moveList);
}

//ascii table
void PrintBoard(PIECE** board){
    PIECE* tmpPiece = NULL;
    int countery = 8;
    for(int i = 7; i > -1; i--){
        printf("%d | ", countery);
        countery--;
        for(int j = 0; j < 8; j++){
            //printf("%2d ", asciitable[8*i+j]);//tests to see table print order..
            tmpPiece = board[8*i+j];
            if (tmpPiece){
                if (tmpPiece->Color == black) {
                    printf("b");
                }
                else if (tmpPiece->Color == white) {
                    printf("w");
                }
                switch(tmpPiece->PieceType) {
                    case queen:
                        printf("Q ");
                        break;
                    case rook:
                        printf("R ");
                        break;
                    case bishop:
                        printf("B ");
                        break;
                    case knight:
                        printf("N ");
                        break;
                    case king:
                        printf("K ");
                        break;
                    case pawn:
                        printf("P ");
                        break;
                    default:
                        break;
                } //switch
            } //if
            else{
                printf("__ ");
            }
        } //inner for
        printf("\n");
    }// outer for

    printf("    -----------------------\n    ");
    for (int m = 0; m < 8; m++) {
        printf("%2c ", m + 97);
    }
    printf("\n");
/*place pieces*/
}

/* EOF */

