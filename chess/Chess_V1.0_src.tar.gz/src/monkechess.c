// This is the main C function for the team 13 chess program. This
// file will contain the main function as well as the board creation
// function.
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "AI.h"
#include "Board.h"
#include "Piece.h"
#include "Gui.h"

GtkWidget *window ;
GtkWidget *fixed ; 


GtkWidget *chess_icon;
GtkWidget *chess_icon2;
GtkWidget *table;

GtkWidget *Start;
GtkWidget *Start_AI;
GtkWidget *Quit;
GtkWidget *Secret_Minigame;
gint handler_id;

void PrintMenu();
int secret_minigame();

// Initiallizes Game asset with team values and preps GUI and Log after button is pressed in the Menu
void start_2p_game(GtkWidget *Widget, gpointer data){
        GAME_ASSET *Asset = data;
        
        printf("2 player game started. \n");
        Asset->board = CreateBoard();
        fclose(fopen("./chessLog.txt", "w"));
        Asset->team = 3;
        
        gtk_container_remove(GTK_CONTAINER(window), table);
        table = gtk_table_new(8, 8, TRUE);
        gtk_widget_set_size_request(table, BOARD_WIDTH, BOARD_HEIGHT);
        DrawBoard(Asset);
        fixed = gtk_fixed_new();
        gtk_fixed_put(GTK_FIXED(fixed), table, 0, 0);
        gtk_container_add(GTK_CONTAINER(window), fixed);
        gtk_widget_show_all(window);
        handler_id = g_signal_connect(window, "button_press_event", G_CALLBACK(area_click), Asset);
}

// Initiallizes Game asset with team values and preps GUI and Log after button is pressed in the Menu
// Prompts User with dialog box for color selection
void start_ai_game(GtkWidget *Widget, gpointer data){
        GAME_ASSET *Asset = data;
        GtkWidget *dialog;
   /* Create the widgets */
   dialog = gtk_dialog_new_with_buttons ("Select a color to start",
                                         NULL, GTK_DIALOG_MODAL&
                                         GTK_DIALOG_DESTROY_WITH_PARENT,
                                         ("Black"),
                                          GTK_RESPONSE_ACCEPT,
                                          ("White"),
                                          GTK_RESPONSE_REJECT, NULL);
        
        printf("AI game started. \n");
        Asset->board = CreateBoard();
        fclose(fopen("./chessLog.txt", "w"));
        
        // delete the container and make a new table to draw
        gtk_container_remove(GTK_CONTAINER(window), table);
        table = gtk_table_new(8, 8, TRUE);
        gtk_widget_set_size_request(table, BOARD_WIDTH, BOARD_HEIGHT);
        
        // print dialog menu and save result
        int color_select = gtk_dialog_run(GTK_DIALOG(dialog));

        // handles the team selection from the user and allows AI to make a move if player is black
        switch(color_select){
          case -3: //black chosen
            Asset->team = black;
            make_ai_move(Asset);
          break;
          case -2: //white chosen
            Asset->team = white;
          break;
        }

        // draw the board and reconnect the mouse handling
        DrawBoard(Asset);
        fixed = gtk_fixed_new();
        gtk_fixed_put(GTK_FIXED(fixed), table, 0, 0);
        gtk_container_add(GTK_CONTAINER(window), fixed);
        gtk_widget_show_all(window);
        gtk_widget_destroy(dialog);
        gtk_widget_show_all(window);
        handler_id = g_signal_connect(window, "button_press_event", G_CALLBACK(area_click), Asset); 
        
}

int main(int   argc,
      char *argv[]) {
  
   // allocate memory for the game assets
   GAME_ASSET* Asset = malloc(sizeof(GAME_ASSET));

  // make arrays of the filepaths for easy access
    char *d_w[6] ={"./bin/Pieces/dark_w_pawn.png",  "./bin/Pieces/dark_w_knight.png",   "./bin/Pieces/dark_w_bishop.png",  "./bin/Pieces/dark_w_rook.png",  "./bin/Pieces/dark_w_queen.png",  "./bin/Pieces/dark_w_king.png" };
    char *d_b[6] ={"./bin/Pieces/dark_b_pawn.png",  "./bin/Pieces/dark_b_knight.png",   "./bin/Pieces/dark_b_bishop.png",  "./bin/Pieces/dark_b_rook.png",  "./bin/Pieces/dark_b_queen.png",  "./bin/Pieces/dark_b_king.png" };
    char *l_w[6] ={"./bin/Pieces/light_w_pawn.png", "./bin/Pieces/light_w_knight.png",  "./bin/Pieces/light_w_bishop.png", "./bin/Pieces/light_w_rook.png", "./bin/Pieces/light_w_queen.png", "./bin/Pieces/light_w_king.png"};
    char *l_b[6] ={"./bin/Pieces/light_b_pawn.png", "./bin/Pieces/light_b_knight.png",  "./bin/Pieces/light_b_bishop.png", "./bin/Pieces/light_b_rook.png", "./bin/Pieces/light_b_queen.png", "./bin/Pieces/light_b_king.png"};


    Asset->dark_white  = d_w;
    Asset->dark_black  = d_b;
    Asset->light_white = l_w;
    Asset->light_black = l_b;
    Asset->light       = "./bin/Pieces/light.png";
    Asset->dark        = "./bin/Pieces/dark.png";
    // makes a place to store the board for GUI interaction
    Asset->board       = NULL;
    // stores player team
    Asset->team        = 1;
    // makes list for things like en passant
    Asset->pastmoves = malloc(sizeof(MOVELIST));
    Asset->pastmoves->Length = 0;
    Asset->pastmoves->First = NULL;
    Asset->pastmoves->Last = NULL;
    
  // initialize graphics library  
  gtk_init(&argc, &argv) ;
  InitBoard(Asset);

  /*create a new window */
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL) ;
  gtk_widget_set_size_request(window, WINDOW_WIDTH, WINDOW_HEIGHT) ; 
  gtk_container_set_border_width (GTK_CONTAINER(window), WINDOW_BORDER) ; 
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER) ; 
  gtk_window_set_title(GTK_WINDOW(window), "Monkechess") ; 
  gtk_window_set_resizable(GTK_WINDOW(window), FALSE) ; 

  
  // make a menu with buttons
  table = gtk_table_new(3, 4, TRUE);
  gtk_table_set_row_spacings(GTK_TABLE(table), 2);
  gtk_table_set_col_spacings(GTK_TABLE(table), 2);

  Start = gtk_button_new_with_label("Start 2 Player Game");
  Start_AI = gtk_button_new_with_label("Start Game Against AI");
  Quit = gtk_button_new_with_label("Quit Game");
  Secret_Minigame = gtk_button_new_with_label("Secret_Minigame");

  gtk_table_attach_defaults(GTK_TABLE(table), Start, 1, 3, 0, 1);
  gtk_table_attach_defaults(GTK_TABLE(table), Start_AI, 1, 3, 1, 2);
  gtk_table_attach_defaults(GTK_TABLE(table), Quit, 1, 3, 2,3);
  gtk_table_attach_defaults(GTK_TABLE(table), Secret_Minigame, 1, 3, 3,4);

  gtk_container_add(GTK_CONTAINER(window), table);

  
  
  
  //Menu event handlers
  g_signal_connect(Start, "clicked",
                  G_CALLBACK(start_2p_game), Asset);

  g_signal_connect(Start_AI, "clicked", 
                  G_CALLBACK(start_ai_game), Asset);

  g_signal_connect(Quit, "clicked",
                  G_CALLBACK(on_delete_event), NULL);

  g_signal_connect(Secret_Minigame, "clicked", 
                  G_CALLBACK(secret_minigame), NULL);

  

  // handles when window is closed
  g_signal_connect(window, "delete_event", G_CALLBACK(on_delete_event), NULL); 
  gtk_widget_set_events(window, GDK_BUTTON_PRESS_MASK) ; 

  // saves handler for the click event and disables it until after start menu 
  handler_id = g_signal_connect(window, "button_press_event", G_CALLBACK(area_click), Asset); 
  g_signal_handler_disconnect(window, handler_id);
 

  gtk_widget_show_all(window); 

  gtk_main(); 
}
int secret_minigame(){
    gtk_main_quit();

  Colors turncolor = white;
  int moved;

  int OptionSelect = 0;
  PIECE** board = NULL;
  MOVE* move = NULL;
  MOVELIST * pastmoves = NULL;
  unsigned int StartingPointX = 0;
  unsigned int StartingPointY = 0;
  unsigned int EndingPointX = 0;
  unsigned int EndingPointY = 0;
  int Quit = 1;
  Colors AiColor = 69;
  char userin;

    pastmoves = malloc(sizeof(MOVELIST));
    if(!pastmoves){
        printf("Out of memory for past move list! Exiting...");
        exit(10);
    }

    pastmoves->Length = 0;
    pastmoves->First = NULL;
    pastmoves->Last = NULL;
    //end of create move list

  while(OptionSelect == 0) {
    PrintMenu();
    printf("Select: ");
    scanf("%2d", &OptionSelect);

    switch(OptionSelect) {
      case 1:
        printf("Starting Game w/o AI\n\n");
        board = CreateBoard();
        PrintBoard(board);
        //Clears the chess log at the start of a new game
        fclose(fopen("./chessLog.txt", "w"));
        break;
      case 2:
        printf("Starting Game w/ AI\n\n");
        printf("Choose color to play as W for white or B for black: ");
        scanf(" %c", &userin);
        switch (userin)
        {
          case 'W':
            AiColor = black;
            break;
          case 'w':
            AiColor = black;
            break;
          case 'B':
            AiColor = white;
            break;
          case 'b':
            AiColor = white;
            break;
          default:
            AiColor = black;
            break;
        }
        board = CreateBoard();
        PrintBoard(board);
        fclose(fopen("./chessLog.txt", "w"));
        break;
      case 3:
        printf("Quit Sucessfully\n");
        return 0;
      default:
        printf("Not valid option\n");
        break;
    } /*switch*/
  } 
  


  /*show the window*/
  while(Quit){
    //if not AI get player input
    if (AiColor != turncolor){
      printf("At any point input 69 for any coordinate, and 0 for everything else, to quit. \n");
      printf("Input move with starting x, starting y, ending x, ending y seperated by spaces: ");
      scanf("%d %d %d %d", &StartingPointX, &StartingPointY, &EndingPointX, &EndingPointY);
      if (StartingPointX == 69 || StartingPointY == 69 || EndingPointX == 69 || EndingPointY == 69){
        Quit = 0;
        printf("Quitting\n");
        break;
      }
      StartingPointX--;
      StartingPointY--;
      EndingPointX--;
      EndingPointY--;

      if (StartingPointX > 7 || StartingPointY > 7 || EndingPointX > 7 || EndingPointY > 7){
        printf("\nThis move is not legal!\n\n");
        PrintBoard(board);
        continue;
      }

      //make sure there is a piece at the input
      if (board[StartingPointY * 8 + StartingPointX]) {
        //make sure piece is right color
        if (board[StartingPointY * 8 + StartingPointX]->Color == turncolor) {
          //move piece
          moved = MovePiece(board, board[StartingPointY * 8 + StartingPointX], StartingPointX, StartingPointY, EndingPointX, EndingPointY, pastmoves, turncolor, 0);

          //if move is successful, change color
          if (moved == 0){
            move = CreateMove(board[EndingPointY * 8 + EndingPointX], StartingPointX, StartingPointY, EndingPointX, EndingPointY);
            AppendMove(pastmoves, move);
            if (turncolor == white) {
              turncolor = black;
              printf("\nIt is Black's turn\n\n");
            }
            else {
              turncolor = white;
              printf("\nIt is White's turn\n\n");
            }
          }
        }
        else {
          printf("\nwrong color\n\n");
        }
      }
      else {
        printf("\nnot a piece\n\n");
      }
    }
    //if ai's turn
    else {
      RandomMove(board, AiColor,pastmoves);
      if (turncolor == white) {
        turncolor = black;
        printf("\nIt is Black's turn\n\n");
      }
      else {
        turncolor = white;
        printf("\nIt is White's turn\n\n");
      }
    }
    PrintBoard(board);
    StartingPointX = StartingPointY = EndingPointX = EndingPointY = 0;

  }//while
  DeleteBoard(board);
  DeleteMoveList(pastmoves);
  return 0;
}
void PrintMenu() {
  printf("1: Start Game\n");
  printf("2: Start Game w/ ai\n");
  printf("3: Quit Game\n");
  return;
}