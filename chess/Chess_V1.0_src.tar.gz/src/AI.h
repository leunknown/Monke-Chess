/*
    This is the header file for the AI portion of the chess
    program. 

    Included in this header file will be the function declarations
    for AI mechanics.
*/

#ifndef AI_H
#define AI_H

#include <assert.h>
#include <stdlib.h>
#include "Board.h"
#include "Gui.h"

//void BestMove(MOVELIST *moveList);

int RandomMove(PIECE** board, Colors AIColor, MOVELIST* pastlist);


#endif