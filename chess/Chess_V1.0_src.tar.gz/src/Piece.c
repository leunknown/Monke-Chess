#include "Piece.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
PIECE* CreatePiece(Colors color, PieceTypes PieceType) {
    PIECE* piece = malloc(sizeof(PIECE));
    if (!piece) {
        perror("ran out of memory!\n");
        exit (10);
    }
    piece->Color = color;
    piece->PieceType = PieceType;
    piece->HasMoved = false;

    switch(PieceType) {
        case queen:
            piece->Value = 9;
            break;
        case rook:
            piece->Value = 5;
            break;
        case bishop:
            piece->Value = 3;
            break;
        case knight:
            piece->Value = 3;
            break;
        case pawn:
            piece->Value = 1;
            break;
        case king:
            piece->Value = 90;
        default:
            break;
    }
    return piece;
}

void DeletePiece(PIECE *piece) {
    assert(piece);
    free(piece);
}

PIECE* PromotePiece(PIECE *piece, int AIflag) {
    char promoInput;
    assert(piece);
    if (AIflag) {
        promoInput = 'Q';
    }
    else {
        printf("Input piece type for pawn promotion Q for queen, B for bishop, K for knight, or R for rook: ");
        scanf(" %c", &promoInput);
    }
    switch(promoInput){
        case 'Q' :
            piece->PieceType = queen;
            piece->Value = 9;
            break;
        case 'q' :
            piece->PieceType = queen;
            piece->Value = 9;
            break;
        case 'R' :
            piece->PieceType = rook;
            piece->Value = 5;
            break;
        case 'r' :
            piece->PieceType = rook;
            piece->Value = 5;
            break;
        case 'K' :
            piece->PieceType = knight;
            piece->Value = 3;
            break;
        case 'k' :
            piece->PieceType = knight;
            piece->Value = 3;
            break;
        case 'B' :
            piece->PieceType = bishop;
            piece->Value = 3;
            break;
        case 'b' :
            piece->PieceType = bishop;
            piece->Value = 3;
            break;
    }

    return piece;
}


/* EOF */