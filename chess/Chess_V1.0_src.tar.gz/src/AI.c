/*
    This is the C file for the AI portion of the chess
    program. This file will contain the code regarding the AI, or 
    programmed bot, moves for a player versus robot game. 
    
    The bot will be programmed to analyze the chess board state 
    and choose the best move out of them. Ideally, these two processes
    will be done by putting a list of legal moves into a decision tree
    and calculate the best valued move for the bot to make.
*/

#include "AI.h"
#include <time.h>
#include <stdio.h>
/*
void BestMove(MOVELIST *moveList){
    assert(moveList);
}*/

int RandomMove(PIECE** board, Colors AIColor, MOVELIST* pastlist){
    int startx;
    int starty;
    srand(time(NULL));
    int i = rand() % 64;   
    int moved = 1;
    int counter = 0;
    MOVEENTRY *randomMoveEntry = NULL;
    MOVELIST* possibleMoveList = NULL;
    while(1){
        counter++;
        if (counter > 1000) {
            printf("\nai took more than 1000 tries, ai broke (probably checkmate)\n");
            return 1;
        }
        i = (i + 1) % 64;
        if (board[i] != NULL){
            if (board[i]->Color == AIColor){
                startx = i % 8;
                starty = i / 8;
                possibleMoveList = PossibleMoves(board, board[i], startx, starty, pastlist);
                if (possibleMoveList->Length == 0) {
                    continue;
                }
                randomMoveEntry = possibleMoveList->First;
                while (randomMoveEntry) {
                    moved = MovePiece(board, randomMoveEntry->move->piece, randomMoveEntry->move->startx, randomMoveEntry->move->starty, randomMoveEntry->move->endx, randomMoveEntry->move->endy, pastlist, AIColor, 1);
                    if (moved == 3) {
                        printf("\nai in checkmate\n");
                        return 1;
                    }
                    else if(moved == 2) {
                        printf("ai made an illegal move still thinking\n");
                        randomMoveEntry = randomMoveEntry->next;
                        continue;
                    }
                    else if (moved == 1) {
                        randomMoveEntry = randomMoveEntry->next;
                        continue;
                    }
                    printf("\n\nai moves %c%d to %c%d\n\n", randomMoveEntry->move->startx+97, randomMoveEntry->move->starty+1, randomMoveEntry->move->endx+97, randomMoveEntry->move->endy+1);
                    DeleteMoveList(possibleMoveList);
                    return 0;
                }
            }
        }
    }
}