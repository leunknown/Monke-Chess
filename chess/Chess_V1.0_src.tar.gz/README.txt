This is the not complete version of the chess program. Type  

    "./bin/monkechess"

 after installation to run.
