This is the not complete version of the chess program. Type  
"make -C src"
and then 
"make run"
 after installation to run.
