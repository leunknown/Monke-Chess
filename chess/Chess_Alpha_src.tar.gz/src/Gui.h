/*
    Project for EECS22L Spring 2022

    Initial Author: Zachary Nicholson

    Gui.h: header file for Graphical interaction with the chess game
*/

#ifndef _GUI_H
#define _GUI_H


#define MAX_MSGLEN  100 
#define SQUARE_SIZE 50  
#define WINDOW_BORDER 10
#define BOARD_BORDER 10
#define BOARD_WIDTH  (8*SQUARE_SIZE)
#define BOARD_HEIGHT (8*SQUARE_SIZE)
#define WINDOW_WIDTH  (BOARD_WIDTH + 2*BOARD_BORDER)
#define WINDOW_HEIGHT (BOARD_HEIGHT + 2*BOARD_BORDER)

enum GRID
{
	BLACK = 0,
	WHITE = 1,
};

enum PIECES           // for inital testing, will use passed Piece struct
{
   empty = 0,
    p = 1
    
};




int gui_init(int argc, char *argv[]);
#endif