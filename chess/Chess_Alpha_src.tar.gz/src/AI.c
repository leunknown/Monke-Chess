/*
    This is the C file for the AI portion of the chess
    program. This file will contain the code regarding the AI, or 
    programmed bot, moves for a player versus robot game. 
    
    The bot will be programmed to analyze the chess board state 
    and choose the best move out of them. Ideally, these two processes
    will be done by putting a list of legal moves into a decision tree
    and calculate the best valued move for the bot to make.
*/

#include "AI.h"
/*
void BestMove(MOVELIST *moveList){
    assert(movelist);
}*/