/*
    Project for EECS22L Spring 2022

    Initial Author: Zachary Nicholson

    Piece.h: header file for basic piece manipulation 
*/

#ifndef PIECE_H
#define PIECE_H

#include <stdbool.h>

typedef enum {black, white} Colors;
typedef enum {pawn, knight, 
              bishop, rook, 
              queen, king} PieceTypes;

typedef struct {
    Colors Color;
    PieceTypes PieceType;
    bool HasMoved;
    int Value;
} PIECE;

//Creates and allocates memory for a new piece, returns a pointer to new piece
PIECE* CreatePiece(Colors color, PieceTypes PieceType);

// Release the memory space for the Piece values
// Release the memory space for the Piece
void DeletePiece(PIECE *piece);

// Promote a piece
// Changes a pieces type and value
PIECE* PromotePiece(PIECE *piece, PieceTypes PieceType);

#endif

/* EOF */