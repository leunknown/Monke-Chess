#include "Board.h"
#include <stdio.h>
#include <stdlib.h>

#define BOARDSIZE 8
#define BOARDLENGTH 64

#include <assert.h>
#include <stdio.h>
    
//alloc board memory
PIECE** CreateBoard(void) {
    PIECE* array[BOARDLENGTH];
    PIECE** Board = malloc(sizeof(array));
    if (!Board) {
        perror("ran out of memory!\n");
        exit(11);
    }

    //creating white pawns
    for (int i = 0; i < BOARDSIZE; i++) {
        Board[8 + i] = CreatePiece(white, pawn);    // [1][i]
    }
    //add white rooks
    Board[0] = CreatePiece(white, rook); // [0][0]
    Board[7]= CreatePiece(white, rook); // [0][BOARDSIZE - 1]
    //add white knights
    Board[1] = CreatePiece(white, knight);  // [0][1]
    Board[6] = CreatePiece(white, knight);  // [0][BOARDSIZE - 2]
    //add white bishop
    Board[2] = CreatePiece(white, bishop);  // [0][2]
    Board[5] = CreatePiece(white, bishop);  // [0][BOARDSIZE - 3]
    //add white king/queen
    Board[3] = CreatePiece(white, queen);   // [0][3]
    Board[4] = CreatePiece(white, king);    // [0][BOARDSIZE - 4]

    //creating black pawns
    for(int j = 0; j < BOARDSIZE; j++) {
        Board[48 + j] = CreatePiece(black, pawn);
    }
    //add black rooks
    Board[56] = CreatePiece(black, rook); // [BOARDSIZE - 1][0]
    Board[63] = CreatePiece(black, rook); // [BOARDSIZE - 1][BOARDSIZE - 1]
    //add black knights
    Board[57] = CreatePiece(black, knight);   // [BOARDSIZE - 1][1]
    Board[62] = CreatePiece(black, knight);   // [BOARDSIZE - 1][BOARDSIZE - 2]
    //add black bishop
    Board[58] = CreatePiece(black, bishop);   // [BOARDSIZE - 1][2]
    Board[61] = CreatePiece(black, bishop);   // [BOARDSIZE - 1][BOARDSIZE - 3]
    //add black king/queen
    Board[59] = CreatePiece(black, queen);    // [BOARDSIZE - 1][3]
    Board[60] = CreatePiece(black, king); // [BOARDSIZE - 1][BOARDSIZE - 4]

    return Board;
}

//free board and all pieces on it
void DeleteBoard(PIECE** board) {
    assert(board);
    for (int i = 0; i < BOARDLENGTH; i++) {
        if(board[i]) {
            DeletePiece(board[i]);
            board[i] = NULL;
        }
    }

    free(board);
    return;
}

// This is the move list which will be used to hold all
// possible moves that are possible for a player in a given board
// returns move list
MOVELIST* PossibleMoves(PIECE** Board, PIECE* piece, unsigned int startx, unsigned int starty){
    //basically the create movelist
    MOVELIST* moveList = NULL;
    moveList = malloc(sizeof(MOVELIST));
    if(!moveList){
        printf("Out of memory for move list! Exiting...");
        exit(10);
    }

    moveList->Length = 0;
    moveList->First = NULL;
    moveList->Last = NULL;
    //end of create move list

    MOVE* tmpMove = NULL;
    int counter = 1;

    //append moves depending on piece type
    switch(piece->PieceType) {
        case queen:
            //continue incrementing counter until you reach the end of the board
            //add moves for every direction
            while(1) {
                //move up
                if (starty + counter < 8) {
                    tmpMove = CreateMove(piece, startx, starty, startx, starty + counter);
                    AppendMove(moveList, tmpMove);
                }
                //move down
                if (starty - counter >= 0) {
                    tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                    AppendMove(moveList, tmpMove);
                }
                //move right
                if (startx + counter < 8) {
                    tmpMove = CreateMove(piece, startx, starty, startx + counter, starty);
                    AppendMove(moveList, tmpMove);
                }
                //move left
                if (startx - counter >= 0) {
                    tmpMove = CreateMove(piece, startx, starty, startx - counter, starty);
                    AppendMove(moveList, tmpMove);
                }
                //move up and right
                if (startx + counter < 8 && starty + counter < 8) {
                    tmpMove = CreateMove(piece, startx, starty, startx + counter, starty + counter);
                    AppendMove(moveList, tmpMove);
                }
                //move up and left
                if (startx - counter >= 0 && starty + counter < 8) {
                    tmpMove = CreateMove(piece, startx, starty, startx - counter, starty + counter);
                    AppendMove(moveList, tmpMove);
                }
                //move down and left
                if (startx - counter >= 0 && starty - counter >= 0) {
                    tmpMove = CreateMove(piece, startx, starty, startx - counter, starty - counter);
                    AppendMove(moveList, tmpMove);
                }
                //move down and right
                if (startx + counter < 8 && starty - counter >= 0) {
                    tmpMove = CreateMove(piece, startx, starty, startx + counter, starty - counter);
                    AppendMove(moveList, tmpMove);
                }
                if (counter == 7) {
                    break;
                }
                counter++;
            }
            break;
        case rook:
            //add moves for vertical and horizontal direction
            while(1) {
                //move up
                if (starty + counter < 8) {
                    tmpMove = CreateMove(piece, startx, starty, startx, starty + counter);
                    AppendMove(moveList, tmpMove);
                }
                //move down
                if (starty - counter >= 0) {
                    tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                    AppendMove(moveList, tmpMove);
                }
                //move right
                if (startx + counter < 8) {
                    tmpMove = CreateMove(piece, startx, starty, startx + counter, starty);
                    AppendMove(moveList, tmpMove);
                }
                //move left
                if (startx - counter >= 0) {
                    tmpMove = CreateMove(piece, startx, starty, startx - counter, starty);
                    AppendMove(moveList, tmpMove);
                }
                if (counter == 7) {
                    break;
                }
                counter++;
            }
            break;
        case bishop:
            //append moves in diagonal
            while(1) {
                //move up and right
                if (startx + counter < 8 && starty + counter < 8) {
                    tmpMove = CreateMove(piece, startx, starty, startx + counter, starty + counter);
                    AppendMove(moveList, tmpMove);
                }
                //move up and left
                if (startx - counter >= 0 && starty + counter < 8) {
                    tmpMove = CreateMove(piece, startx, starty, startx - counter, starty + counter);
                    AppendMove(moveList, tmpMove);
                }
                //move down and left
                if (startx - counter >= 0 && starty - counter >= 0) {
                    tmpMove = CreateMove(piece, startx, starty, startx - counter, starty - counter);
                    AppendMove(moveList, tmpMove);
                }
                //move down and right
                if (startx + counter < 8 && starty - counter >= 0) {
                    tmpMove = CreateMove(piece, startx, starty, startx + counter, starty - counter);
                    AppendMove(moveList, tmpMove);
                }
                if (counter == 7) {
                    break;
                }
                counter++;
            }
            break;
        case knight:
            //move up2 then right1
            if (startx + 1 < 8 && starty + 2 < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx + 1, starty + 2);
                AppendMove(moveList, tmpMove);
            }
            //move up then left
            if (startx - 1 >= 0 && starty + 2 < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx - 1, starty + 2);
                AppendMove(moveList, tmpMove);
            }
            //move down then left
            if (startx - 1 >= 0 && starty - 2 >= 0) {
                tmpMove = CreateMove(piece, startx, starty, startx - 1, starty - 2);
                AppendMove(moveList, tmpMove);
            }
            //move down then right
            if (startx + 1 < 8 && starty - 2 >= 0) {
                tmpMove = CreateMove(piece, startx, starty, startx + 1, starty - 2);
                AppendMove(moveList, tmpMove);
            }
            //move right then up
            if (startx + 2 < 8 && starty + 1 < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx + 2, starty + 1);
                AppendMove(moveList, tmpMove);
            }
            //move right then down
            if (startx + 2 < 8 && starty - 1 >= 0) {
                tmpMove = CreateMove(piece, startx, starty, startx + 2, starty - 1);
                AppendMove(moveList, tmpMove);
            }
            //move left then up
            if (startx - 2 >= 0 && starty + 1 < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx - 2, starty + 1);
                AppendMove(moveList, tmpMove);
            }
            //move left then down
            if (startx - 2 >= 0 && starty - 1 >= 0) {
                tmpMove = CreateMove(piece, startx, starty, startx - 2, starty - 1);
                AppendMove(moveList, tmpMove);
            }
            break;
        case king:
            //only add moves for counter = 1
            //any direction
            //move up
            if (starty + counter < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx, starty + counter);
                AppendMove(moveList, tmpMove);
            }
            //move down
            if (starty - counter >= 0) {
                tmpMove = CreateMove(piece, startx, starty, startx, starty - counter);
                AppendMove(moveList, tmpMove);
            }
            //move right
            if (startx + counter < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx + counter, starty);
                AppendMove(moveList, tmpMove);
            }
            //move left
            if (startx - counter >= 0) {
                tmpMove = CreateMove(piece, startx, starty, startx - counter, starty);
                AppendMove(moveList, tmpMove);
            }
            //move up and right
            if (startx + counter < 8 && starty + counter < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx + counter, starty + counter);
                AppendMove(moveList, tmpMove);
            }
            //move up and left
            if (startx - counter >= 0 && starty + counter < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx - counter, starty + counter);
                AppendMove(moveList, tmpMove);
            }
            //move down and left
            if (startx - counter >= 0 && starty - counter >= 0) {
                tmpMove = CreateMove(piece, startx, starty, startx - counter, starty - counter);
                AppendMove(moveList, tmpMove);
            }
            //move down and right
            if (startx + counter < 8 && starty - counter >= 0) {
                tmpMove = CreateMove(piece, startx, starty, startx + counter, starty - counter);
                AppendMove(moveList, tmpMove);
            }
            break;
        case pawn:
            //move up 1
            if (starty + 1 < 8) {
                tmpMove = CreateMove(piece, startx, starty, startx, starty + 1);
                AppendMove(moveList, tmpMove);
            }
            //move up 2
            if (starty + 2 < 8 && !(piece->HasMoved)) {
                tmpMove = CreateMove(piece, startx, starty, startx, starty + 2);
                AppendMove(moveList, tmpMove);
            }
            break;
        default:
            break;
    } //switch

    return moveList;
}


//create move structs to add to list
MOVE* CreateMove(PIECE* piece, unsigned int startx, unsigned int starty, unsigned int endx, unsigned int endy){
    MOVE* move = NULL;
    move = malloc(sizeof(MOVE));

    if(!move){
        printf("Move not created! Exiting...");
        exit(11);
    }

    move->piece = piece;
    move->startx = startx;
    move->starty = starty;
    move->endx = endx;
    move->endy = endy;

    return move;
}

//check if move is legal using movelist of all possible moves
//if move is legal return 1
//if illegal return 0
//if no possible moves, return 2
int LegalMoveCheck(PIECE** Board, MOVE* move) {
    assert(Board);
    assert(move);
    MOVELIST* moveList = NULL;
    moveList = PossibleMoves(Board, move->piece, move->startx, move->starty);
    MOVEENTRY* entry = moveList->First;
    int legal = 0;

    //if no moves checkmate
    if (moveList->Length == 0) {
        legal = 2;
    }
    //check if legal move
    else {
        while(entry) {
            //basically, if our move is the exact same as one in our possible moves list
            if ((move->starty == entry->move->starty) && (move->startx == entry->move->startx) && (move->endy == entry->move->endy) && (move->endx == entry->move->endx)) {
                    legal = 1;
                }
            entry = entry->next;
        }
    }
    DeleteMoveList(moveList);
    //if our move is not in the list return 0
    return legal;
}

//move and capture in the array (FOR PLAYER)

void MovePiece(PIECE** board, PIECE* piece, unsigned int startx, unsigned int starty, unsigned int endx, unsigned int endy){
    PIECE* movePiece = NULL;
    MOVE* move = NULL;
    move = CreateMove(piece, startx, starty, endx, endy);
    int legal = LegalMoveCheck(board, move);
    DeleteMove(move);

    if (legal == 0) {
        printf("This move is not legal!\n\n");
        return;
    } 
    if (legal == 2) {
        printf("You are in checkmate please quit\n\n");
        return;
    }
    else {
        //if the is a piece at the end point, delete it
        if(board[(endx) + (endy * 8)]) {
            printf("\n%d%d is taken by %d%d\n\n", endx + 1, endy + 1, startx + 1, starty + 1);
            DeletePiece(board[(endx) + (endy * 8)]);
        }
        //move start Piece to end position and null start
        movePiece = board[startx + (starty * 8)];
        board[(endx) + (endy * 8)] = movePiece;
        board[startx + (starty * 8)] = NULL;
        //now states that piece has been moved.
        piece->HasMoved = true;
    }
}

//delete move
void DeleteMove(MOVE* move){
    assert(move);
    free(move);
}

/* added by Theo edited by Justin*/
void AppendMove(MOVELIST* moveList, MOVE* move){
    MOVEENTRY* moveEntry; //temp variable m for move.
    assert(moveList);
    assert(move);
    //basically the create move entry
    //alloc entry
    moveEntry = malloc(sizeof(MOVEENTRY));
    if (! moveEntry) {
        perror("Out of memory! AppendMove Aborting...");
	    exit(12);
    }

    moveEntry->list = moveList;
    moveEntry->move = move;
    moveEntry->next = NULL;
    moveEntry->prev = moveList->Last;
    //end of create entry

    if (moveList->Last) {
        moveList->Last->next = moveEntry;
        moveList->Last = moveEntry;
    }
    else {
        moveList->First = moveEntry;
        moveList->Last = moveEntry;
    }
    moveList->Length++;
}

//delete list and entries
void DeleteMoveList(MOVELIST *moveList) {
    assert(moveList);
    MOVEENTRY *entry = NULL;
    MOVEENTRY *nextEntry = NULL;

    entry = moveList->First;

    while(entry) {
        DeleteMove(entry->move);
        nextEntry = entry->next;
        free(entry);
        entry = nextEntry;
    }
    free(moveList);
}

void PrintBoard(PIECE** board){
/*asciitable*/
    PIECE* tmpPiece = NULL;
    int countery = 8;
    for(int i = 7; i > -1; i--){
        printf("%d | ", countery);
        countery--;
        for(int j = 0; j < 8; j++){
            //printf("%2d ", asciitable[8*i+j]);//tests to see table print order..
            tmpPiece = board[8*i+j];
            if (tmpPiece){
                if (tmpPiece->Color == black) {
                    printf("b");
                }
                else if (tmpPiece->Color == white) {
                    printf("w");
                }
                switch(tmpPiece->PieceType) {
                    case queen:
                        printf("Q ");
                        break;
                    case rook:
                        printf("R ");
                        break;
                    case bishop:
                        printf("B ");
                        break;
                    case knight:
                        printf("N ");
                        break;
                    case king:
                        printf("K ");
                        break;
                    case pawn:
                        printf("P ");
                        break;
                    default:
                        break;
                } //switch
            } //if
            else{
                printf("__ ");
            }
        } //inner for
        printf("\n");
    }// outer for

    printf("    -----------------------\n    ");
    for (int m = 0; m < 8; m++) {
        printf("%2d ", m + 1);
    }
    printf("\n");
/*place pieces*/

}
/* EOF */

