// This is the main C function for the team 13 chess program. This
// file will contain the main function as well as the board creation
// function.
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "AI.h"
#include "Board.h"
#include "Piece.h"
#include "Gui.h"

void PrintMenu();

int main(int   argc,
      char *argv[]) {
  
  // Allows for gui interface to be selected from the command line
  int i = 0;
  while (i < argc){
    if (strcmp(argv[i], "-gui") == 0) {
    	gui_init(argc, argv); 
	}
		i++;    
  }

  int OptionSelect = 0;
  PIECE** board = NULL;
  int StartingPointX = 0;
  int StartingPointY = 0;
  int EndingPointX = 0;
  int EndingPointY = 0;
  int Quit = 1;

  while(OptionSelect == 0) {
    PrintMenu();
    printf("Select: ");
    scanf("%2d", &OptionSelect);

    switch(OptionSelect) {
      case 1:
        printf("Starting Game\n\n");
        board = CreateBoard();
        PrintBoard(board);
        break;
      case 2:
        printf("Quit Sucessfully\n");
        return 0;
      default:
        printf("Not valid option\n");
        break;
    } /*switch*/
  }
  while(Quit){
    printf("At any point input 69 for any coordinate, and 0 for everything else, to quit. \n");
    printf("Input move with starting x, starting y, ending x, ending y seperated by spaces: ");
    scanf("%d %d %d %d", &StartingPointX, &StartingPointY, &EndingPointX, &EndingPointY);
    if (StartingPointX == 69 || StartingPointY == 69 || EndingPointX == 69 || EndingPointY == 69){
      Quit = 0;
      printf("Quitting\n");
      break;
    }
    StartingPointX--;
    StartingPointY--;
    EndingPointX--;
    EndingPointY--;
    MovePiece(board, board[StartingPointY * 8 + StartingPointX], StartingPointX, StartingPointY, EndingPointX, EndingPointY);
    PrintBoard(board);
  }
  DeleteBoard(board);
  return 0;
}
void PrintMenu() {
  printf("1: Start Game\n");
  printf("2: Quit Game\n");
  return;
}