/*
    Project for EECS22L Spring 2022

    Initial Author: Zachary Nicholson

    Gui.c: header file for Graphical interaction with the chess game
*/

#include <gtk/gtk.h>
#include "Gui.h"
#include "string.h"




GtkWidget *window ;
GtkWidget *fixed ; 

GtkWidget *chess_icon ;
GtkWidget *table; 

int startx = 8; // if 8, 8 no piece
int starty = 8;
int endx = 8; 
int endy = 8; 

enum GRID Board[8][8];     // Stores space color reference
enum PIECES g_board[8][8]; // temp variable used for testing, may need changed

// Initialize a reference checkerboard of 0's and 1's to denote light and dark squares
void InitBoard(){                                 
    for (int i = 0; i < 8; i++){
        for (int j = 0; j < 8; j++){
            if(j%2){
                if(i%2){
                    Board[i][j] = WHITE;
                }
                else{
                    Board[i][j] = BLACK; }
                            }
            else{
                if(i%2){
                    Board[i][j] = BLACK;
                }
                else{
                    Board[i][j] = WHITE;
                }
            }
        }
    }
}

void ResetBoard(){
    InitBoard();
}

/* void MoveTheKing(int g_x, int g_y)      // legacy code from the example file
{
	ResetBoard();
	Board[g_x][g_y] = KING;
} */

void gui_move_piece()                               // called from MovePiece(), only affects the 2 squares in the move path
{
	g_board[startx][starty] = empty;
    switch (Board[startx][starty]){
        case BLACK:
            chess_icon = gtk_image_new_from_file("./Pieces/dark.bmp");      // load a blank dark space
        break;
        case WHITE:
            chess_icon = gtk_image_new_from_file("./Pieces/light.bmp");     // load a blank light space
        break;
    }
    gtk_table_attach(GTK_TABLE(table), chess_icon, startx, startx + 1, starty, starty + 1, GTK_FILL, GTK_FILL, 0, 0);

	g_board[endx][endy] = p;
    switch(Board[endx][endy]){
        case BLACK:
            chess_icon = gtk_image_new_from_file("./Pieces/dark_w_pawn.bmp"); // load a w pawn on a dark space
        break;
        case WHITE:
            chess_icon = gtk_image_new_from_file("./Pieces/light_w_pawn.bmp"); // load a w pawn on a light space
        break;
    }
    gtk_table_attach(GTK_TABLE(table), chess_icon, endx, endx + 1, endy, endy + 1, GTK_FILL, GTK_FILL, 0, 0);

    
} 

void DrawBoard(){                                          // unfinished & inefficient, draws entire board over and chooses what type of space to show
    for (int i = 0; i < 8; i++){
        for (int j = 0; j < 8; j++){
            switch(Board[i][j])
			{
				case BLACK:
                    switch (g_board[i][j]){
                        case empty:
					    chess_icon = gtk_image_new_from_file("./Pieces/dark.bmp");
                        break;
                        case p:
                        chess_icon = gtk_image_new_from_file("./Pieces/dark_w_pawn.bmp");
                        break;
                    }
					break;
				case WHITE:
					switch (g_board[i][j]){
                        case empty:
					    chess_icon = gtk_image_new_from_file("./Pieces/light.bmp");
                        break;
                        case p:
                        chess_icon = gtk_image_new_from_file("./Pieces/light_w_pawn.bmp");
                        break;
                    }
				default:
					break;
            }
        	gtk_table_attach(GTK_TABLE(table), chess_icon, i, i + 1, j, j + 1, GTK_FILL, GTK_FILL, 0, 0);
        }
    }
}

/* void DrawBoard()
{
	int i, j;

    for(i = 0; i < 2; i ++)
	{
		for(j = 0; j < 2; j ++)
		{
			switch(Board[i][j])
			{
				case BLACK:
					chess_icon = gtk_image_new_from_file("./chess_icon/Bsquare.jpg") ;
					break;
				case WHITE:
					chess_icon = gtk_image_new_from_file("./chess_icon/Wsquare.jpg") ;
					break;
				case KING:
					chess_icon = gtk_image_new_from_file("./chess_icon/WKing.jpg") ;
					break;
				default:
					break;
				
			}
			gtk_table_attach(GTK_TABLE(table), chess_icon, i, i + 1, j, j + 1, GTK_FILL, GTK_FILL, 0, 0) ;
		}
	}
} */

void CoordToGrid(int c_x, int c_y, int *g_x, int *g_y){  // converts graphical coordinates to rank and file
	*g_x = (c_x - BOARD_BORDER) / SQUARE_SIZE;
	*g_y = (c_y - BOARD_BORDER) / SQUARE_SIZE;
}

static gboolean on_delete_event (GtkWidget *widget,   // Returns false to hard quit the gui interface, can be changed in future versions
         GdkEvent  *event,
         gpointer   data){
  

  g_print ("delete event occurred\n"); 
  gtk_main_quit();
  return FALSE;
}

gint area_click (GtkWidget *widget,             // GtkCallback function triggered on mouse click
                 GdkEvent  *event,              // gets coords and calls CoordToGrid()
                 gpointer  data) {              // then decides if move should be stored and displayed or not
  // int x1, y1 ; (NOTE THIS WAS COMMENTED TO HAVE CLEAN COMPILE)
  // char words[MAX_MSGLEN] ; (NOTE THIS WAS COMMENTED TO HAVE CLEAN COMPILE)

  int coord_x, coord_y, grid_x, grid_y; 

  //struct BOARD *chess_board ; 
  //struct SQUARE *chess_piece ;
  //struct SQUARE *piece_dest ;   

  GdkModifierType state ; 

  gdk_window_get_pointer(widget->window, &coord_x, &coord_y, &state) ; 

  CoordToGrid(coord_x, coord_y, &grid_x, &grid_y);

  printf("coord_x = %d, coord_y = %d, grid_x = %d, grid_y = %d \n", coord_x, coord_y, grid_x, grid_y);

    gtk_container_remove(GTK_CONTAINER(window), fixed) ; 
    table = gtk_table_new (8, 8, TRUE) ;
    gtk_widget_set_size_request (table, BOARD_WIDTH, BOARD_HEIGHT) ;
    DrawBoard(); 
    
 if ((startx && starty) == 8){                         // if first click on the board, needs to check for players piece
      startx = grid_x;
      starty = grid_y;
  }
  else if((endx && endy) ==8){                         // if second click after first click on a piece, needs to check if legal before displaying
      endx = grid_x;
      endy = grid_y;
  }
    
 
if (!((startx && starty && endx && endy) == 8)){        // if start and end coords are satisfied, execute move and reset coords
  gui_move_piece(grid_x, grid_y);
  startx = starty = endx = endy = 8;
} 


    /*set fixed*/

    fixed = gtk_fixed_new() ;
    gtk_fixed_put(GTK_FIXED(fixed), table, 0, 0) ;
    gtk_container_add(GTK_CONTAINER(window), fixed) ;
    gtk_widget_show_all(window) ; 

  return TRUE ; 
}



int gui_init(int argc, char *argv[]){
  // char str[MAX_MSGLEN]; (NOTE THIS WAS COMMENTED TO HAVE CLEAN COMPILE)
    
  gtk_init(&argc, &argv) ;
  ResetBoard();
 
  /*create a new window */
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL) ;
  gtk_widget_set_size_request(window, WINDOW_WIDTH, WINDOW_HEIGHT) ; 
  gtk_container_set_border_width (GTK_CONTAINER(window), WINDOW_BORDER) ; 
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER) ; 
  gtk_window_set_title(GTK_WINDOW(window), "Let's play Chess!") ; 
  gtk_window_set_resizable(GTK_WINDOW(window), FALSE) ; 


  /*register event handlers*/
  g_signal_connect(window, "delete_event", G_CALLBACK(on_delete_event), NULL) ; 
  gtk_widget_set_events(window, GDK_BUTTON_PRESS_MASK) ; 
  g_signal_connect(window, "button_press_event", G_CALLBACK(area_click), NULL) ; 

  /*create a table and draw the board*/
  table = gtk_table_new (8, 8, TRUE) ; 
  gtk_widget_set_size_request (table, BOARD_WIDTH, BOARD_HEIGHT) ; 
  DrawBoard();

  fixed = gtk_fixed_new() ; 
  gtk_fixed_put(GTK_FIXED(fixed), table, 0, 0) ; 
  gtk_container_add(GTK_CONTAINER(window), fixed) ; 


  /*show the window*/
  gtk_widget_show_all(window) ; 
  gtk_main() ; 

  return 0 ;
} 