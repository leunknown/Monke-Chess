#include "Piece.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
PIECE* CreatePiece(Colors color, PieceTypes PieceType) {
    PIECE* piece = malloc(sizeof(PIECE));
    if (!piece) {
        perror("ran out of memory!\n");
        exit (10);
    }
    piece->Color = color;
    piece->PieceType = PieceType;
    piece->HasMoved = false;

    switch(PieceType) {
        case queen:
            piece->Value = 9;
            break;
        case rook:
            piece->Value = 5;
            break;
        case bishop:
            piece->Value = 3;
            break;
        case knight:
            piece->Value = 3;
            break;
        case pawn:
            piece->Value = 1;
            break;
        case king:
            piece->Value = 90;
        default:
            break;
    }
    return piece;
}

void DeletePiece(PIECE *piece) {
    assert(piece);
    free(piece);
}

PIECE* PromotePiece(PIECE *piece, PieceTypes PieceType) {
    assert(piece);
    piece->PieceType = PieceType;
    switch(PieceType) {
        case queen:
            piece->Value = 9;
            break;
        case rook:
            piece->Value = 5;
            break;
        case bishop:
            piece->Value = 3;
            break;
        case knight:
            piece->Value = 3;
            break;
        default:
            break;
    }
    return piece;
}


/* EOF */