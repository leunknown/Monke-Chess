/*
    This is the Board header file which will contain
    the function declarations necessary for the Board.c
    file.
*/

#ifndef BOARD_H
#define BOARD_H

#include "Piece.h"

//Move struct tells where to move piece
typedef struct mlist MOVELIST;
typedef struct mentry MOVEENTRY;
typedef struct m MOVE;

struct m {
    PIECE* piece;
    unsigned int startx;
    unsigned int starty;
    unsigned int endx;
    unsigned int endy;
};

//entry for linked list
struct mentry {
    MOVELIST *list;
    MOVEENTRY *next;
    MOVEENTRY *prev;
    MOVE *move;
};

//doublely linked list for moves
struct mlist{
    unsigned int Length;
    MOVEENTRY* First;
    MOVEENTRY* Last;
};

/* *****NOTE****** */
// Possibility that piece structure is uncessary 
// for the MOVE struct. Check to make sure later


// Function that creates a board for the chess pieces
// and then returns a pointer to the board which is just
// a bunch of empty squares and pieces.
PIECE** CreateBoard(void);

// Deletes the board pointer as well as the piece structs and 
// any other structure used by the Board.
void DeleteBoard(PIECE** board);

// Creates a move structure which will be appended in another
// function.
MOVE* CreateMove(PIECE* piece, unsigned int startx, unsigned int starty, unsigned int endx, unsigned int endy);

// This function will delete the move structure by freeing
// all the memory allocated.
void DeleteMove(MOVE* move);

// This will append a move into the move list.
void AppendMove(MOVELIST* moveList, MOVE* move);

// This function will check if the out of the possible moves
// that a piece can make is legal or not. This will return an
// integer that determines this.
int LegalMoveCheck(PIECE** Board, MOVE* move);

// This will check all possible moves avaiable to a specific chess
// piece and return a list of the moves.
// creates the move list
MOVELIST* PossibleMoves(PIECE** Board, PIECE* piece, unsigned int startx, unsigned int starty);

// This function will move the piece structure to the new 
// board address. 
void MovePiece(PIECE** board, PIECE* piece, unsigned int startx, unsigned int starty, unsigned int endx, unsigned int endy);

//deletes movelist and delete entries combined
void DeleteMoveList(MOVELIST *moveList);

//void Movement(PIECE* piece);

void PrintBoard(PIECE** board);


#endif
// EOF